export interface TechItem {
  name: string;
  role: string;
}

export interface LearningResource {
  title: string;
  type: 'Documentation' | 'Course' | 'Interactive' | 'Tool' | 'Guide';
  url: string;
  desc: string;
}

export interface DocLink {
  title: string;
  url: string;
  desc: string;
}

export interface CategoryDetail {
  slug: string;
  route: string;
  parentCategory: string;
  parentHref: string;
  title: string;
  subtitle: string;
  tagline: string;
  badge: string;
  accentColor?: string;
  heroImage: string;
  fallbackImage: string;
  overview: string;
  keyFeatures: string[];
  techStack: TechItem[];
  coreTopics: { title: string; desc: string }[];
  learningResources: LearningResource[];
  documentationLinks: DocLink[];
  relatedRoutes: { title: string; route: string; description: string }[];
}

export const CATEGORIES_DATA: Record<string, CategoryDetail> = {
  // -------------------------------------------------------------
  // APP DEVELOPMENT
  // -------------------------------------------------------------
  'android': {
    slug: 'android',
    route: '/app-development/android',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'Android App Development',
    subtitle: 'Build High-Performance Native Mobile Experiences for Billions of Devices',
    tagline: 'Modern Android with Jetpack Compose, Kotlin Multiplatform, and Clean Architecture',
    badge: 'Mobile Engineering',
    heroImage: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1400&q=80',
    overview: 'Android development is the discipline of creating mobile applications for the world’s most widely adopted operating system. Contemporary Android development emphasizes declarative UI through Jetpack Compose, asynchronous reactivity powered by Kotlin Coroutines & Flow, and scalable modular clean architecture. Developers leverage Android Studio Hedgehog/Iguana with powerful linting, profilers, and emulator suites to build rock-solid, fluid applications that run smoothly across smartphones, foldable devices, and automotive head units.',
    keyFeatures: [
      'Declarative UI with Jetpack Compose for reactive, state-driven interfaces',
      'Coroutines & Kotlin Flows for non-blocking asynchronous concurrency',
      'Dependency Injection with Dagger Hilt for testable, modular architectures',
      'Room Persistence Library with SQLite for robust offline-first synchronization',
      'Material 3 (You) dynamic theming with adaptive responsive layouts',
      'WorkManager for reliable, deferrable background job execution',
      'Comprehensive profiling tools for GPU overdraw, memory leaks, and battery usage'
    ],
    techStack: [
      { name: 'Kotlin', role: 'Primary Language' },
      { name: 'Jetpack Compose', role: 'Modern UI Toolkit' },
      { name: 'Android Studio', role: 'Official IDE' },
      { name: 'Gradle (KTS)', role: 'Build Automation' },
      { name: 'Hilt / Koin', role: 'Dependency Injection' },
      { name: 'Retrofit & OkHttp', role: 'REST Networking' }
    ],
    coreTopics: [
      { title: 'Android Architecture Components', desc: 'ViewModel, LiveData/StateFlow, Repository pattern, and Clean Architecture separation of concerns.' },
      { title: 'Jetpack Compose Fundamentals', desc: 'Recomposition lifecycle, State hoisting, Modifiers, Canvas graphics, and custom animations.' },
      { title: 'Offline-First Data Flow', desc: 'Single Source of Truth (SSOT) using Room database cache backed by remote REST/GraphQL synchronization.' },
      { title: 'App Security & Proguard/R8', desc: 'Code obfuscation, Keystore cryptographic signing, encrypted SharedPreferences, and network security configs.' },
      { title: 'Testing & CI/CD', desc: 'JUnit 5, MockK, Espresso UI tests, Compose UI testing, and automated GitHub Actions deployment pipelines.' }
    ],
    learningResources: [
      { title: 'Android Basics with Compose', type: 'Course', url: 'https://developer.android.com/courses/android-basics-compose/course', desc: 'Official Google training curriculum for modern Android development.' },
      { title: 'Now in Android Repository', type: 'Interactive', url: 'https://github.com/android/nowinandroid', desc: 'Production-grade reference app showcasing Google’s official architecture guidance.' },
      { title: 'Kotlin Coroutines on Android', type: 'Guide', url: 'https://developer.android.com/kotlin/coroutines', desc: 'In-depth guide on handling asynchronous background tasks efficiently.' }
    ],
    documentationLinks: [
      { title: 'Android Developer Documentation', url: 'https://developer.android.com/docs', desc: 'Official documentation and API reference for Android SDK.' },
      { title: 'Jetpack Compose API Guide', url: 'https://developer.android.com/jetpack/compose', desc: 'Comprehensive API documentation for Compose UI toolkit.' },
      { title: 'Android Security Best Practices', url: 'https://developer.android.com/privacy-and-security', desc: 'Hardening Android apps against vulnerabilities and data leaks.' }
    ],
    relatedRoutes: [
      { title: 'Kotlin Development', route: '/app-development/kotlin', description: 'Master the primary language powering modern Android.' },
      { title: 'Android Studio', route: '/app-development/android-studio', description: 'Deep-dive into IDE shortcuts, profilers, and debugging.' },
      { title: 'APK Reverse Engineering', route: '/app-development/apk-reverse-engineering', description: 'Understand APK compilation, DEX bytecode, and security auditing.' }
    ]
  },

  'kotlin': {
    slug: 'kotlin',
    route: '/app-development/kotlin',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'Kotlin Development',
    subtitle: 'Concise, Expressive, and Multiplatform Systems Programming',
    tagline: 'Empowering Modern Android, Full-Stack Server, and Native Applications',
    badge: 'Core Language',
    heroImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1400&q=80',
    overview: 'Kotlin is a modern, statically typed language developed by JetBrains and championed by Google as the premier language for Android development. Designed to eliminate null pointer exceptions with compile-time null safety, Kotlin dramatically reduces boilerplate while maintaining 100% interoperability with Java. With Kotlin Multiplatform (KMP), developers can share business logic across iOS, Android, Desktop, and Backend servers without giving up native performance.',
    keyFeatures: [
      'First-class Null Safety built directly into the type system to eradicate NPEs',
      'Lightweight Coroutines for structured, highly efficient concurrent operations',
      'Extension functions enabling clean API enhancements without inheritance overhead',
      'Smart casting and sealed class hierarchies for exhaustive pattern matching',
      'Kotlin Multiplatform (KMP) code sharing across iOS, Android, and Web',
      'Data classes with auto-generated equals, hashCode, and copy functionality',
      'Seamless bi-directional interoperability with existing Java codebases'
    ],
    techStack: [
      { name: 'Kotlin Compiler (K2)', role: 'Next-Gen Compilation' },
      { name: 'Coroutines', role: 'Async Runtime' },
      { name: 'Ktor', role: 'Async Server & Client Framework' },
      { name: 'Kotlinx.serialization', role: 'Cross-platform JSON Parsing' },
      { name: 'Kotest', role: 'Testing & Property Verification' }
    ],
    coreTopics: [
      { title: 'Type System & Nullability', desc: 'Nullable vs non-nullable types, safe calls (?.), Elvis operator (?:), and smart cast mechanism.' },
      { title: 'Functional Programming Idioms', desc: 'Higher-order functions, lambdas with receiver, inline functions, and sequence collections.' },
      { title: 'Structured Concurrency', desc: 'Coroutine scopes, Dispatchers, cancellation cooperative flow, and Exception handling.' },
      { title: 'Reactive Data Streams with Flow', desc: 'Cold Flows, SharedFlow, StateFlow, operators, backpressure handling, and Compose collection.' },
      { title: 'Kotlin Multiplatform (KMP)', desc: 'expect/actual declarations, multiplatform project layout, and iOS native bindings.' }
    ],
    learningResources: [
      { title: 'Kotlin Official Playground', type: 'Interactive', url: 'https://play.kotlinlang.org', desc: 'Browser-based execution environment to test Kotlin snippets.' },
      { title: 'Kotlin by Example', type: 'Guide', url: 'https://play.kotlinlang.org/byExample/overview', desc: 'Bite-sized, practical examples explaining each core Kotlin feature.' },
      { title: 'Kotlin Multiplatform Documentation', type: 'Documentation', url: 'https://kotlinlang.org/docs/multiplatform.html', desc: 'Complete guide for cross-platform shared logic implementation.' }
    ],
    documentationLinks: [
      { title: 'Official Kotlin Docs', url: 'https://kotlinlang.org/docs/home.html', desc: 'Comprehensive language specification and standard library reference.' },
      { title: 'Coroutines Guide', url: 'https://kotlinlang.org/docs/coroutines-guide.html', desc: 'Complete guide from basics to advanced channels and flow.' },
      { title: 'Kotlin Coding Conventions', url: 'https://kotlinlang.org/docs/coding-conventions.html', desc: 'Official style guide for maintainable idiomatic Kotlin.' }
    ],
    relatedRoutes: [
      { title: 'Android App Development', route: '/app-development/android', description: 'Apply Kotlin in production mobile applications.' },
      { title: 'Java Development', route: '/app-development/java', description: 'Explore the JVM foundation and Java interoperability.' },
      { title: 'Android Studio', route: '/app-development/android-studio', description: 'Leverage JetBrains tooling for high-speed development.' }
    ]
  },

  'java': {
    slug: 'java',
    route: '/app-development/java',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'Java Development',
    subtitle: 'The Enterprise Titan Powering Scalable JVM Ecosystems',
    tagline: 'Robust, Object-Oriented Computing from Android Fundamentals to Cloud Microservices',
    badge: 'Enterprise & Systems',
    heroImage: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1400&q=80',
    overview: 'Java remains one of the world’s most foundational programming languages, driving millions of Android applications, enterprise architectures, and mission-critical cloud backends. With modern Java (21 LTS with Virtual Threads/Project Loom), Java combines rock-solid object-oriented principles, garbage collection optimizations, and memory efficiency with modern ergonomics like pattern matching, record classes, and lightweight concurrency.',
    keyFeatures: [
      'Virtual Threads (Project Loom) for lightweight high-throughput concurrency',
      'Battle-tested JVM garbage collection engines (ZGC, Shenandoah, G1)',
      'Record classes and Sealed Interfaces for algebraic data modeling',
      'Strongly typed Object-Oriented design patterns and encapsulation',
      'Massive ecosystem with Spring Boot, Micronaut, Quarkus, and Android SDK',
      'Cross-platform bytecode execution under "Write Once, Run Anywhere"',
      'Enterprise-grade security features and cryptographic key management'
    ],
    techStack: [
      { name: 'OpenJDK 21 LTS', role: 'Java Runtime Environment' },
      { name: 'Spring Boot 3', role: 'Microservice Framework' },
      { name: 'Maven / Gradle', role: 'Dependency Management' },
      { name: 'JUnit 5 & Mockito', role: 'Automated Testing' },
      { name: 'Hibernate / JPA', role: 'Database ORM' }
    ],
    coreTopics: [
      { title: 'OOP Principles & SOLID', desc: 'Polymorphism, abstraction, interface segregation, and loose coupling architectures.' },
      { title: 'Java Concurrency Utilities', desc: 'Executors, CompletableFuture, ReentrantLock, synchronization, and Virtual Threads.' },
      { title: 'JVM Memory Model & Internals', desc: 'Heap, Stack, Metaspace, GC cycles, classloader hierarchy, and memory profilers.' },
      { title: 'Modern Java Syntax Evolution', desc: 'Records, Pattern Matching for switch, Text Blocks, and Stream API functional pipelines.' },
      { title: 'Android Runtime (ART) vs JVM', desc: 'DEX format compilation, Ahead-Of-Time (AOT) vs JIT compilation, and Android Java APIs.' }
    ],
    learningResources: [
      { title: 'Dev.java Official Portal', type: 'Documentation', url: 'https://dev.java', desc: 'The official home for Java developers by Oracle.' },
      { title: 'Java Design Patterns', type: 'Guide', url: 'https://java-design-patterns.com', desc: 'Open-source catalog of production-grade Java design patterns.' },
      { title: 'Baeldung Java Tutorials', type: 'Course', url: 'https://www.baeldung.com', desc: 'Deep-dive practical guides into Java, Spring, and JVM tools.' }
    ],
    documentationLinks: [
      { title: 'Java SE 21 API Specification', url: 'https://docs.oracle.com/en/java/javase/21/docs/api/', desc: 'Official API documentation for Java standard library.' },
      { title: 'Spring Framework Documentation', url: 'https://spring.io/projects/spring-framework', desc: 'Reference manuals for Spring enterprise ecosystem.' }
    ],
    relatedRoutes: [
      { title: 'Android App Development', route: '/app-development/android', description: 'See how Java connects to Android internals.' },
      { title: 'APK Reverse Engineering', route: '/app-development/apk-reverse-engineering', description: 'Decompile APK DEX files back into readable Java code.' },
      { title: 'Node.js Backend', route: '/web-development/nodejs', description: 'Compare JVM services with async JavaScript runtimes.' }
    ]
  },

  'apk-reverse-engineering': {
    slug: 'apk-reverse-engineering',
    route: '/app-development/apk-reverse-engineering',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'APK Reverse Engineering',
    subtitle: 'Deconstruct, Analyze, and Inspect Android Application Bytecode',
    tagline: 'Ethical Security Auditing, Binary Analysis, and Smali Bytecode Disassembly',
    badge: 'Cybersecurity & Pentesting',
    heroImage: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1400&q=80',
    overview: 'APK Reverse Engineering is an indispensable skill for mobile security researchers, penetration testers, and advanced Android engineers. Android packages (.apk) are ZIP archives bundling compiled Dalvik Executable (.dex) files, resources, native libraries (.so), and manifest declarations. Through decompilation with JADX, disassembly via Apktool/Baksmali, and dynamic hooking using Frida, researchers inspect application logic, audit hardcoded secrets, detect security vulnerabilities, and inspect network communication pipelines.',
    keyFeatures: [
      'Decompilation of Dalvik bytecode into high-level Java code with JADX GUI/CLI',
      'Disassembly and rebuilding of binary resources and Smali code via Apktool',
      'Dynamic instrumentation and runtime API hooking utilizing Frida and Objection',
      'Static Application Security Testing (SAST) with MobSF (Mobile Security Framework)',
      'Inspection and decompilation of Native C/C++ shared libraries (.so) using Ghidra',
      'SSL Pinning bypass and network MITM traffic inspection with Burp Suite / Mitmproxy',
      'APK signature verification auditing (v1, v2, v3, v4 schemes) using apksigner'
    ],
    techStack: [
      { name: 'JADX', role: 'DEX to Java Decompiler' },
      { name: 'Apktool', role: 'Resource & Smali Disassembler' },
      { name: 'Frida', role: 'Dynamic Runtime Hooking' },
      { name: 'Ghidra / IDA', role: 'Native Binary Analysis' },
      { name: 'MobSF', role: 'Automated Security Assessment' },
      { name: 'Burp Suite', role: 'HTTP/HTTPS Proxy & Interception' }
    ],
    coreTopics: [
      { title: 'APK Package Structure', desc: 'Understanding classes.dex, AndroidManifest.xml, res/ resources, assets/, and lib/ architecture ABIs.' },
      { title: 'Dalvik VM & Smali Opcode Syntax', desc: 'Registers (v0, p0), method invocation directives (invoke-virtual, invoke-static), and conditional branches.' },
      { title: 'Decompilation vs Disassembly', desc: 'Differences between reconstructing Java source code (JADX) and reversible assembler bytecode (Smali).' },
      { title: 'Root Detection & Anti-Tamper Bypasses', desc: 'Identifying checks for su binaries, test-keys, Magisk, and using Frida scripts to patch return values.' },
      { title: 'Hardcoded Secrets Auditing', desc: 'Extracting exposed AWS keys, Firebase tokens, internal endpoints, and sensitive crypto initialization vectors.' }
    ],
    learningResources: [
      { title: 'OWASP Mobile Security Testing Guide (MASTG)', type: 'Guide', url: 'https://mas.owasp.org/MASTG/', desc: 'The definitive comprehensive manual for mobile app security testing and reverse engineering.' },
      { title: 'JADX GitHub Repository', type: 'Tool', url: 'https://github.com/skylot/jadx', desc: 'Dex to Java decompiler command line and GUI tools.' },
      { title: 'Apktool Documentation', type: 'Documentation', url: 'https://apktool.org/docs', desc: 'Official guide for decoding and rebuilding APK resources.' }
    ],
    documentationLinks: [
      { title: 'OWASP Mobile Application Security', url: 'https://mas.owasp.org', desc: 'Industry benchmark standard for mobile security testing.' },
      { title: 'Frida Official Docs', url: 'https://frida.re/docs/home/', desc: 'Dynamic instrumentation toolkit for developers and reverse engineers.' },
      { title: 'Android Dalvik Bytecode Spec', url: 'https://source.android.com/docs/core/runtime/dalvik-bytecode', desc: 'Official instruction formats and opcode table.' }
    ],
    relatedRoutes: [
      { title: 'APK Analysis & Security', route: '/app-development/apk-analysis', description: 'Deep dive into static vulnerability scanning.' },
      { title: 'Android App Development', route: '/app-development/android', description: 'Learn how apps are originally constructed.' },
      { title: 'Java Development', route: '/app-development/java', description: 'Read de-obfuscated JVM and Dalvik logic.' }
    ]
  },

  'apk-analysis': {
    slug: 'apk-analysis',
    route: '/app-development/apk-analysis',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'APK Analysis & Security',
    subtitle: 'Deep-Dive Vulnerability Auditing, Permission Analysis, and Component Hardening',
    tagline: 'Defend Android Applications Against Attack Vectors and Privacy Leaks',
    badge: 'App Security',
    heroImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1510511459019-5dda7724fd87?auto=format&fit=crop&w=1400&q=80',
    overview: 'APK Analysis is the systematic inspection of compiled Android packages to verify compliance with privacy guidelines, examine attack surfaces, and ensure defensive resilience. By analyzing exported Activity, BroadcastReceiver, ContentProvider, and Service components, security engineers identify unintended intent redirection, SQL injection in providers, unprotected deeplinks, and excessive dangerous permissions.',
    keyFeatures: [
      'Exported Android component auditing to prevent unauthorized intent access',
      'ContentProvider path traversal and SQL injection vulnerability testing',
      'AndroidManifest.xml permission surface and flag analysis (allowBackup, debuggable)',
      'Automated Static & Dynamic security pipeline integration via CI/CD',
      'Deep link verification and intent filter validation against phishing vectors',
      'Memory dumps and clipboard leak detection in sensitive payment apps'
    ],
    techStack: [
      { name: 'MobSF', role: 'Automated SAST/DAST' },
      { name: 'Drozer', role: 'Security Assessment Framework' },
      { name: 'QARK', role: 'Quick Android Review Kit' },
      { name: 'Apktool', role: 'Manifest Inspector' }
    ],
    coreTopics: [
      { title: 'Android Component Exposure', desc: 'Risks of android:exported="true" without explicit custom permissions or signature protection.' },
      { title: 'Insecure Data Storage', desc: 'Shared preferences, SQLite databases, external storage caches, and SDCard privacy risks.' },
      { title: 'Insecure Communication', desc: 'Cleartext HTTP traffic, unverified SSL certificates, and custom X509TrustManager flaws.' },
      { title: 'Cryptographic Pitfalls', desc: 'Hardcoded AES keys, ECB mode usage, static IVs, and deprecated DES/MD5 algorithms.' }
    ],
    learningResources: [
      { title: 'OWASP Mobile Top 10', type: 'Guide', url: 'https://owasp.org/www-project-mobile-top-10/', desc: 'The 10 most critical mobile application security risks.' },
      { title: 'MobSF Live Demo & Docs', type: 'Tool', url: 'https://mobsf.github.io/docs/', desc: 'Automated mobile security framework manual.' }
    ],
    documentationLinks: [
      { title: 'Android App Security Guide', url: 'https://developer.android.com/privacy-and-security/security-best-practices', desc: 'Official Android security practices and guidelines.' },
      { title: 'Android Permissions Reference', url: 'https://developer.android.com/guide/topics/permissions/overview', desc: 'Comprehensive permissions overview.' }
    ],
    relatedRoutes: [
      { title: 'APK Reverse Engineering', route: '/app-development/apk-reverse-engineering', description: 'Disassemble bytecode to trace vulnerabilities.' },
      { title: 'Android App Development', route: '/app-development/android', description: 'Implement defensive secure coding techniques.' }
    ]
  },

  'app-ui-ux-design': {
    slug: 'app-ui-ux-design',
    route: '/app-development/app-ui-ux-design',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'App UI/UX Design',
    subtitle: 'Craft Intuitive, Cyber-Inspired, and Ergonomic Mobile Interfaces',
    tagline: 'Material You, Futuristic Glassmorphism, Micro-Interactions, and User Centricity',
    badge: 'Design & Experience',
    heroImage: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1400&q=80',
    overview: 'Outstanding mobile applications pair robust engineering with compelling visual design and ergonomic usability. App UI/UX design focuses on touch-first ergonomics, thumb-zone navigation, intuitive information hierarchy, and smooth, responsive micro-interactions. With modern design tools like Figma, designers architect scalable design systems, tokenized color palettes, and motion choreographies that translate seamlessly into Jetpack Compose and Flutter.',
    keyFeatures: [
      'Design systems architecture with reusable tokens, variants, and component sets',
      'Material 3 (Material You) adaptive design with dynamic user-centric theming',
      'Futuristic dark mode and cybernetic glassmorphism aesthetics with neon accents',
      'Thumb-zone mobile usability optimization for one-handed operation',
      'Fluid micro-interactions and transition choreographies that delight users',
      'Strict accessibility compliance (WCAG 2.1 AA) for contrast and screen readers'
    ],
    techStack: [
      { name: 'Figma', role: 'Collaborative UI/UX Prototyping' },
      { name: 'Material Theme Builder', role: 'Token & Palette Generator' },
      { name: 'Lottie', role: 'Vector Motion Animations' },
      { name: 'Principle / ProtoPie', role: 'High-Fidelity Interaction' }
    ],
    coreTopics: [
      { title: 'Mobile Information Architecture', desc: 'Bottom sheet navigation, tabbed structures, and contextual action flows.' },
      { title: 'Design Token Handoff', desc: 'Exporting typography, spacing, elevations, and semantic colors directly to Compose code.' },
      { title: 'Accessibility & Contrast', desc: 'Accessible touch targets (minimum 48x48dp), color blindness testing, and TalkBack semantics.' }
    ],
    learningResources: [
      { title: 'Material Design 3 Guidelines', type: 'Documentation', url: 'https://m3.material.io', desc: 'The definitive guide to Material You and modern Android design.' },
      { title: 'Figma Mobile Design System', type: 'Guide', url: 'https://www.figma.com/community', desc: 'Community design files and starter kits for mobile UI.' }
    ],
    documentationLinks: [
      { title: 'Material You System', url: 'https://m3.material.io/foundations', desc: 'Color, typography, and shape foundations.' },
      { title: 'Android UI Guidelines', url: 'https://developer.android.com/design', desc: 'Official Android design principles and patterns.' }
    ],
    relatedRoutes: [
      { title: 'Android App Development', route: '/app-development/android', description: 'Implement UI designs in Jetpack Compose.' },
      { title: 'Flutter Development', route: '/app-development/flutter', description: 'Build cross-platform UI widgets in Flutter.' }
    ]
  },

  'android-studio': {
    slug: 'android-studio',
    route: '/app-development/android-studio',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'Android Studio Mastery',
    subtitle: 'Maximize Speed, Profiling, and Build Automation in Google’s Official IDE',
    tagline: 'Advanced Debugging, Memory Leaks Tracking, Emulator Suites, and Gradle Optimization',
    badge: 'Developer Tooling',
    heroImage: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80',
    overview: 'Android Studio is the official Integrated Development Environment (IDE) built on JetBrains IntelliJ IDEA, purpose-engineered for Android software engineering. It combines intelligent code completion, Kotlin/Java refactoring engines, Gradle build system tooling, real-time Compose Previews, and enterprise-grade hardware profiling tools (CPU, Memory, Network, Battery) into a unified workstation.',
    keyFeatures: [
      'Interactive Jetpack Compose Previews with multipreview annotations and animations inspector',
      'Android Studio Profiler for measuring CPU traces, memory allocation, and energy consumption',
      'Layout Inspector for live 3D view hierarchy debugging on real devices and emulators',
      'Gradle build speed optimizations using configuration cache, build cache, and daemon tuning',
      'App Inspection suite supporting SQLite Room live query inspection and WorkManager status',
      'Advanced breakpoint debugging with conditional triggers, method tracing, and logpoints'
    ],
    techStack: [
      { name: 'Android Studio Hedgehog/Iguana', role: 'Official IDE' },
      { name: 'Gradle KTS', role: 'Build Automation' },
      { name: 'Android Emulator', role: 'Hardware Virtualization' },
      { name: 'LeakCanary', role: 'Memory Leak Detection' }
    ],
    coreTopics: [
      { title: 'Speeding Up Gradle Builds', desc: 'Enabling org.gradle.caching, parallel execution, and fine-tuning JVM heap allocation.' },
      { title: 'Memory Leak Hunting', desc: 'Capturing heap dumps, locating retention paths in LeakCanary, and fixing static context leaks.' },
      { title: 'Live Edit & Hot Reloading', desc: 'Updating Compose UI elements in real-time on connected devices without rebuilding.' }
    ],
    learningResources: [
      { title: 'Android Studio User Guide', type: 'Documentation', url: 'https://developer.android.com/studio/intro', desc: 'Official documentation for IDE features and shortcuts.' },
      { title: 'Android Studio Profiler Guide', type: 'Guide', url: 'https://developer.android.com/studio/profile', desc: 'Tutorials on auditing app performance and resource bottlenecks.' }
    ],
    documentationLinks: [
      { title: 'Android Studio Release Notes', url: 'https://developer.android.com/studio/releases', desc: 'Latest tooling features and preview releases.' }
    ],
    relatedRoutes: [
      { title: 'Android App Development', route: '/app-development/android', description: 'Write production Android code inside the IDE.' },
      { title: 'Kotlin Development', route: '/app-development/kotlin', description: 'Utilize Kotlin IDE refactorings and lints.' }
    ]
  },

  'flutter': {
    slug: 'flutter',
    route: '/app-development/flutter',
    parentCategory: 'App Development',
    parentHref: '#app-dev',
    title: 'Flutter Development',
    subtitle: 'Cross-Platform Native Apps with Dart and Skia/Impeller Rendering',
    tagline: 'Single Codebase for Android, iOS, Desktop, and Web with 120 FPS Rendering',
    badge: 'Cross-Platform',
    heroImage: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=1400&q=80',
    overview: 'Flutter is Google’s open-source UI software development kit that allows developers to compile high-performance applications for Android, iOS, Web, and Desktop from a single codebase written in Dart. Unlike traditional hybrid frameworks that bridge through web views or JavaScript runtimes, Flutter controls every pixel directly via its modern Impeller rendering engine, ensuring buttery smooth 60–120 FPS animations and lightning-fast Stateful Hot Reload.',
    keyFeatures: [
      'Stateful Hot Reload for sub-second UI updates without losing application state',
      'Next-generation Impeller graphics engine eliminating shader compilation jank',
      'Extensive catalog of pixel-perfect Material and Cupertino (iOS-style) widgets',
      'Predictable state management solutions (Bloc, Riverpod, Provider)',
      'Direct compilation to native ARM64 machine code for near-zero runtime latency',
      'Platform Channels and FFI for seamless C/C++, Java, and Swift native bridging'
    ],
    techStack: [
      { name: 'Dart 3', role: 'Null-Safe Programming Language' },
      { name: 'Flutter Engine / Impeller', role: 'Hardware-Accelerated Renderer' },
      { name: 'Riverpod / Bloc', role: 'State Management' },
      { name: 'Dio', role: 'HTTP Client' },
      { name: 'Hive / Isar', role: 'Fast NoSQL Storage' }
    ],
    coreTopics: [
      { title: 'Widget Lifecycle & Tree', desc: 'StatelessWidget vs StatefulWidget, Element Tree, RenderObject, and BuildContext.' },
      { title: 'State Management Architecture', desc: 'Unidirectional data flow, reactive streams, and separation of UI from business logic with Riverpod.' },
      { title: 'Custom Animations & Gestures', desc: 'AnimationController, Tween sequences, implicit animated widgets, and Hero transitions.' },
      { title: 'Native Device Integration', desc: 'MethodChannel communication with Android (Kotlin) and iOS (Swift) native SDKs.' }
    ],
    learningResources: [
      { title: 'Flutter Official Codelabs', type: 'Interactive', url: 'https://docs.flutter.dev/codelabs', desc: 'Guided hands-on coding tutorials for beginners and pros.' },
      { title: 'Flutter Widget of the Week', type: 'Guide', url: 'https://www.youtube.com/playlist?list=PLjxrf2q8roU23XGwz3Km7sQZFTdB996iG', desc: 'Bite-sized official deep-dives into essential widgets.' }
    ],
    documentationLinks: [
      { title: 'Flutter Official Docs', url: 'https://docs.flutter.dev', desc: 'Comprehensive API reference, tutorials, and architecture guides.' },
      { title: 'Dart Language Tour', url: 'https://dart.dev/guides/language/language-tour', desc: 'Complete introduction to Dart language syntax.' }
    ],
    relatedRoutes: [
      { title: 'Android App Development', route: '/app-development/android', description: 'Explore native Android platform features.' },
      { title: 'App UI/UX Design', route: '/app-development/app-ui-ux-design', description: 'Design cross-platform UI systems.' },
      { title: 'React Development', route: '/web-development/react', description: 'Compare Flutter with React’s declarative model.' }
    ]
  },

  // -------------------------------------------------------------
  // WEB DEVELOPMENT
  // -------------------------------------------------------------
  'html-css': {
    slug: 'html-css',
    route: '/web-development/html-css',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'HTML5 & Modern CSS3',
    subtitle: 'The Architectural Backbone and Visual Powerhouse of the Modern Web',
    tagline: 'Semantic Markup, Responsive Layouts, CSS Grid, Flexbox, and Modern Design Systems',
    badge: 'Web Foundations',
    heroImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1523437113738-bbd3cc89fb19?auto=format&fit=crop&w=1400&q=80',
    overview: 'HTML5 and CSS3 are the foundational pillars of everything rendered in a web browser. Modern semantic HTML establishes structured, accessible, search-engine-optimized documents that assist assistive technologies. Modern CSS has evolved beyond simple styling into an astonishingly capable graphics and layout engine featuring subgrid, container queries, hardware-accelerated animations, CSS custom properties, and utility frameworks like Tailwind CSS.',
    keyFeatures: [
      'Semantic HTML5 elements (article, section, nav, main, dialog) for accessible markup',
      'Advanced 2D CSS Grid and Flexbox for fluid, dynamic multi-column layouts',
      'Container Queries allowing component-level responsive styling regardless of viewport',
      'Hardware-accelerated CSS animations, 3D transforms, and keyframe transitions',
      'CSS Custom Properties (Variables) enabling instant dynamic runtime theme switching',
      'Modern color spaces (oklch, lch, display-p3) for ultra-vibrant cybernetic palettes'
    ],
    techStack: [
      { name: 'HTML5 Semantic Spec', role: 'Document Structure' },
      { name: 'CSS3 / Modern CSS', role: 'Styling & Animations' },
      { name: 'Tailwind CSS', role: 'Utility-First Framework' },
      { name: 'PostCSS', role: 'CSS Transpilation & Autoprefixing' },
      { name: 'Axe Accessibility', role: 'WCAG Compliance Auditing' }
    ],
    coreTopics: [
      { title: 'Semantic Web & Accessibility (a11y)', desc: 'ARIA attributes, landmark regions, tab indexes, and screen reader announcements.' },
      { title: 'CSS Grid & Subgrid Mastery', desc: 'Implicit/explicit grids, grid-template-areas, minmax(), and nested subgrid alignments.' },
      { title: 'Modern CSS Specificity & Cascade Layers', desc: 'Using @layer to architect unpolluted CSS architectures without specificity conflicts.' }
    ],
    learningResources: [
      { title: 'MDN Web Docs: HTML & CSS', type: 'Documentation', url: 'https://developer.mozilla.org/en-US/docs/Learn', desc: 'The gold standard web development guide by Mozilla.' },
      { title: 'web.dev by Google', type: 'Guide', url: 'https://web.dev/learn/css/', desc: 'Google’s structured guide to learning modern, responsive CSS.' }
    ],
    documentationLinks: [
      { title: 'MDN HTML Reference', url: 'https://developer.mozilla.org/en-US/docs/Web/HTML', desc: 'Complete element and attribute specification.' },
      { title: 'MDN CSS Reference', url: 'https://developer.mozilla.org/en-US/docs/Web/CSS', desc: 'Comprehensive property and function documentation.' }
    ],
    relatedRoutes: [
      { title: 'JavaScript Development', route: '/web-development/javascript', description: 'Add dynamic reactivity to your markup.' },
      { title: 'React Development', route: '/web-development/react', description: 'Build componentized HTML and CSS with JSX.' },
      { title: 'Web Design & UI/UX', route: '/web-development/web-design', description: 'Explore visual design theory and typography.' }
    ]
  },

  'javascript': {
    slug: 'javascript',
    route: '/web-development/javascript',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'JavaScript Development',
    subtitle: 'The Universal Language of the Web and High-Concurrency Event-Driven Runtimes',
    tagline: 'Modern ES2024+, Asynchronous Event Loops, DOM Reactivity, and Full-Stack Versatility',
    badge: 'Universal Language',
    heroImage: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?auto=format&fit=crop&w=1400&q=80',
    overview: 'JavaScript is the bedrock runtime of the interactive internet, executing on billions of clients and high-scale cloud servers worldwide. Powered by modern JIT compilers like V8, SpiderMonkey, and JavaScriptCore, JavaScript combines non-blocking event-driven concurrency, prototype-based object orientation, and modern functional idioms. From browser manipulation to backend APIs, JavaScript is the universal lingua franca of modern technology.',
    keyFeatures: [
      'Non-blocking Event Loop architecture capable of thousands of concurrent I/O operations',
      'Async / Await and Promises for elegant, readable asynchronous control flow',
      'Modern ES6–ES2024 features: destructuring, optional chaining, nullish coalescing',
      'First-class functions, closures, currying, and functional array transformations',
      'High-performance V8 engine optimizations (turbofan, hidden classes, inline caches)',
      'Rich web API ecosystem: WebSockets, Web Workers, IndexedDB, Fetch API'
    ],
    techStack: [
      { name: 'V8 Engine', role: 'High-Performance JIT Runtime' },
      { name: 'TypeScript', role: 'Static Type Checking' },
      { name: 'Vite / ESBuild', role: 'Ultra-Fast Bundling' },
      { name: 'Jest / Vitest', role: 'Test Runner' }
    ],
    coreTopics: [
      { title: 'Event Loop & Call Stack', desc: 'Microtasks vs Macrotasks, Promise job queues, and avoiding UI thread blocking.' },
      { title: 'Closures & Scopes', desc: 'Lexical scoping, memory retention, garbage collection considerations, and module patterns.' },
      { title: 'Prototypes & Inheritance', desc: 'Prototypal chains, Object.create, class syntax desugaring, and memory savings.' }
    ],
    learningResources: [
      { title: 'JavaScript.info (The Modern JS Tutorial)', type: 'Course', url: 'https://javascript.info', desc: 'The most comprehensive step-by-step JavaScript guide in existence.' },
      { title: 'MDN JavaScript Guide', type: 'Documentation', url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide', desc: 'Official Mozilla guide to JavaScript syntax and standards.' }
    ],
    documentationLinks: [
      { title: 'ECMAScript Official Specification', url: 'https://tc39.es/ecma262/', desc: 'The authoritative formal standard for JavaScript.' },
      { title: 'MDN JavaScript Reference', url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference', desc: 'Standard built-in objects and APIs.' }
    ],
    relatedRoutes: [
      { title: 'React Development', route: '/web-development/react', description: 'Harness JavaScript to power declarative UI components.' },
      { title: 'Node.js Backend', route: '/web-development/nodejs', description: 'Run JavaScript on the server for high-scale APIs.' },
      { title: 'Full Stack Development', route: '/web-development/fullstack', description: 'Unify frontend and backend under a single language.' }
    ]
  },

  'react': {
    slug: 'react',
    route: '/web-development/react',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'React Development',
    subtitle: 'The Premier Component-Based Library for Reactive Digital Experiences',
    tagline: 'Declarative State Modeling, Virtual DOM, Hooks, and Server Components',
    badge: 'Frontend Framework',
    heroImage: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=1400&q=80',
    overview: 'React revolutionized modern web engineering by popularizing declarative UI and component-based architectures. By decoupling state changes from direct DOM mutations through a lightweight reconciliation virtual DOM, React guarantees predictable, testable, and reusable user interfaces. With React 19, the ecosystem introduces React Server Components, server actions, and automated compilation for blazing-fast initial page loads.',
    keyFeatures: [
      'Declarative Component Model encouraging clean, self-contained, and testable code',
      'Rich Hooks API (useState, useEffect, useMemo, useCallback, useTransition) for state logic',
      'React Server Components (RSC) shifting data fetching to zero-bundle-size server execution',
      'Concurrent Mode rendering enabling interruptible, lag-free UI updates',
      'Massive ecosystem of UI libraries, state tools (Zustand, Redux Toolkit), and routers',
      'Virtual DOM with Fiber reconciler for highly optimized render batching'
    ],
    techStack: [
      { name: 'React 18 / 19', role: 'UI Library' },
      { name: 'TypeScript', role: 'Type Safety' },
      { name: 'Vite', role: 'Modern Frontend Tooling' },
      { name: 'Tailwind CSS', role: 'Component Styling' },
      { name: 'Zustand / Redux', role: 'Global State Management' }
    ],
    coreTopics: [
      { title: 'Component Lifecycle & Reconciliation', desc: 'Understanding render passes, props vs state, dependency arrays, and key stability.' },
      { title: 'Custom Hooks Architecture', desc: 'Extracting reusable business logic and side effects into clean custom hook abstractions.' },
      { title: 'Performance Profiling', desc: 'Memoization with useMemo, React.memo, and diagnosing unnecessary component re-renders.' }
    ],
    learningResources: [
      { title: 'React.dev Official Documentation', type: 'Documentation', url: 'https://react.dev', desc: 'Interactive, modern official documentation with visual diagrams and challenges.' },
      { title: 'React TypeScript Cheatsheet', type: 'Guide', url: 'https://react-typescript-cheatsheet.netlify.app', desc: 'Comprehensive typing patterns for React components and hooks.' }
    ],
    documentationLinks: [
      { title: 'Official React Reference', url: 'https://react.dev/reference/react', desc: 'Complete hooks and components API catalog.' }
    ],
    relatedRoutes: [
      { title: 'Next.js Development', route: '/web-development/nextjs', description: 'Take React into full-stack production with SSR and SEO.' },
      { title: 'JavaScript Development', route: '/web-development/javascript', description: 'Review the JavaScript foundation powering React.' },
      { title: 'Full Stack Development', route: '/web-development/fullstack', description: 'Combine React with Node.js and cloud databases.' }
    ]
  },

  'nextjs': {
    slug: 'nextjs',
    route: '/web-development/nextjs',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'Next.js Full-Stack Framework',
    subtitle: 'Production-Grade React with Server-Side Rendering and Edge Capabilities',
    tagline: 'App Router, Server Actions, Incremental Static Regeneration, and SEO Dominance',
    badge: 'Full Stack Framework',
    heroImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80',
    overview: 'Next.js is the industry-standard full-stack React framework engineered by Vercel. It bridges the gap between client interactivity and server performance by offering hybrid rendering paradigms: Static Site Generation (SSG), Server-Side Rendering (SSR), and Incremental Static Regeneration (ISR). With the App Router, developers build nested layouts, secure Server Actions, and streaming server components that deliver unmatched SEO, speed, and developer joy.',
    keyFeatures: [
      'App Router featuring nested layouts, error boundaries, and loading states',
      'Server Actions enabling type-safe RPC database mutations directly from components',
      'Image & Font Optimization automatically converting assets to modern WebP/AVIF formats',
      'Incremental Static Regeneration (ISR) updating static pages in the background without rebuilds',
      'Edge Middleware for lightning-fast geo-routing, authentication, and A/B testing',
      'Native SEO optimizations with dynamic metadata and OpenGraph tag generation'
    ],
    techStack: [
      { name: 'Next.js 14 / 15', role: 'Full Stack Framework' },
      { name: 'React Server Components', role: 'Server-First Architecture' },
      { name: 'Vercel Edge Network', role: 'Global Deployment' },
      { name: 'Prisma / Drizzle', role: 'Type-Safe ORM' }
    ],
    coreTopics: [
      { title: 'App Router vs Pages Router', desc: 'Layouts, page.tsx, route handlers, and server vs client component boundaries ("use client").' },
      { title: 'Data Fetching & Caching Strategy', desc: 'fetch() cache options (no-store, force-cache, revalidate), tags, and on-demand revalidation.' },
      { title: 'Server Actions & Form Handling', desc: 'Handling form submissions with optimistic updates and pending states via useFormStatus.' }
    ],
    learningResources: [
      { title: 'Next.js Learn Course', type: 'Course', url: 'https://nextjs.org/learn', desc: 'Official interactive course building a full-stack dashboard from scratch.' }
    ],
    documentationLinks: [
      { title: 'Next.js Documentation', url: 'https://nextjs.org/docs', desc: 'The comprehensive guide to building full-stack applications with Next.js.' }
    ],
    relatedRoutes: [
      { title: 'React Development', route: '/web-development/react', description: 'Review the underlying component foundation.' },
      { title: 'Node.js Backend', route: '/web-development/nodejs', description: 'Explore dedicated backend services and runtimes.' }
    ]
  },

  'nodejs': {
    slug: 'nodejs',
    route: '/web-development/nodejs',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'Node.js Backend Engineering',
    subtitle: 'Scalable, High-Throughput Server-Side Runtimes & Microservices',
    tagline: 'Event-Driven Async I/O, REST/GraphQL APIs, WebSockets, and Distributed Systems',
    badge: 'Backend Architecture',
    heroImage: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1400&q=80',
    overview: 'Node.js enables developers to run JavaScript on the server, unlocking full-stack language unification across the entire engineering pipeline. Built on Chrome’s V8 engine and libuv, Node.js uses an asynchronous, non-blocking I/O model that excels at data-intensive, real-time distributed applications such as chat systems, financial streaming feeds, and microservice architectures handling millions of concurrent requests.',
    keyFeatures: [
      'Asynchronous Event-Driven Libuv threadpool handling non-blocking system calls',
      'Massive NPM registry containing over two million open-source libraries and modules',
      'High-speed streaming APIs for processing massive video and file payloads efficiently',
      'Native support for ECMAScript Modules (ESM) and modern asynchronous utilities',
      'Real-time bi-directional networking via WebSockets and Server-Sent Events (SSE)',
      'Built-in cryptographic utilities for HMAC, hashing, and TLS/HTTPS communication'
    ],
    techStack: [
      { name: 'Node.js 20+ LTS', role: 'Server Runtime' },
      { name: 'Express / Fastify', role: 'Web API Framework' },
      { name: 'PostgreSQL & Redis', role: 'Relational DB & Caching Layer' },
      { name: 'Docker', role: 'Containerization' },
      { name: 'Prisma ORM', role: 'Database Access' }
    ],
    coreTopics: [
      { title: 'Node.js Event Loop Architecture', desc: 'Timers, pending callbacks, poll phase, check (setImmediate), and process.nextTick priority.' },
      { title: 'Streams & Buffer Management', desc: 'Readable, Writable, Transform streams, and preventing backpressure memory crashes.' },
      { title: 'Security & Authentication', desc: 'JWT token signing, refresh token rotation, bcrypt hashing, and rate limiting against DDoS.' }
    ],
    learningResources: [
      { title: 'Node.js Official Learning Track', type: 'Course', url: 'https://nodejs.org/en/learn', desc: 'Official guides covering fundamentals, asynchronous operations, and best practices.' }
    ],
    documentationLinks: [
      { title: 'Node.js API Reference', url: 'https://nodejs.org/docs/latest/api/', desc: 'Complete manual for core Node.js built-in modules.' }
    ],
    relatedRoutes: [
      { title: 'JavaScript Development', route: '/web-development/javascript', description: 'Review the language runtime and syntax.' },
      { title: 'Full Stack Development', route: '/web-development/fullstack', description: 'Integrate Node.js with frontend applications.' }
    ]
  },

  'web-design': {
    slug: 'web-design',
    route: '/web-development/web-design',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'Web Design & Creative Coding',
    subtitle: 'Harmonizing Cyberpunk Aesthetics, Visual Hierarchy, and Usability',
    tagline: 'Dark Mode Glassmorphism, Neon Accents, Typography, and Motion Design',
    badge: 'Visual Arts',
    heroImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=1400&q=80',
    overview: 'Web design is the art and science of shaping compelling digital environments. Beyond pure visual aesthetics, world-class web design establishes effortless usability, emotional resonance, and frictionless conversion pathways. By marrying futuristic cyberpunk palettes (electric neon greens, deep obsidian blacks, sharp red accents) with glassmorphism, designers craft memorable experiences that stand apart from generic templates.',
    keyFeatures: [
      'Futuristic dark mode design systems with glowing neon accents and obsidian backgrounds',
      'Glassmorphism panels using backdrop-filter blur with subtle glowing border highlights',
      'Typographic hierarchy balancing monospace technical fonts with sleek sans-serif body text',
      'Responsive multi-breakpoint design scaling from compact smartphones to ultra-wide monitors',
      'Micro-animations and hover transitions that communicate interactive affordance',
      'WCAG contrast compliance guaranteeing readability for all visual conditions'
    ],
    techStack: [
      { name: 'Figma', role: 'Interface Design' },
      { name: 'Tailwind CSS', role: 'Rapid Styling' },
      { name: 'Framer Motion', role: 'Declarative Web Animations' },
      { name: 'Coolors / RealtimeColors', role: 'Color Palette Engineering' }
    ],
    coreTopics: [
      { title: 'Color Theory in Cyberpunk Design', desc: 'Balancing high-saturation accent colors against dark neutral backgrounds without eye strain.' },
      { title: 'Typographic Scaling & Rhythms', desc: 'Modular scale selection, line-height geometry, and pairing technical monospace with clean sans.' },
      { title: 'Visual Hierarchy & Whitespace', desc: 'Guiding the visitor’s eye through intentional contrast, scale, and spatial padding.' }
    ],
    learningResources: [
      { title: 'Refactoring UI', type: 'Guide', url: 'https://www.refactoringui.com', desc: 'Practical, developer-friendly interface design wisdom by the creators of Tailwind CSS.' }
    ],
    documentationLinks: [
      { title: 'Tailwind CSS Documentation', url: 'https://tailwindcss.com/docs', desc: 'Utility classes and customization documentation.' }
    ],
    relatedRoutes: [
      { title: 'HTML5 & Modern CSS3', route: '/web-development/html-css', description: 'Turn visual designs into real browser code.' },
      { title: 'React Development', route: '/web-development/react', description: 'Build reusable UI design system components.' }
    ]
  },

  'fullstack': {
    slug: 'fullstack',
    route: '/web-development/fullstack',
    parentCategory: 'Web Development',
    parentHref: '#web-dev',
    title: 'Full Stack Development',
    subtitle: 'End-to-End Software Engineering from Pixels to Distributed Databases',
    tagline: 'Bridging Frontend Interactivity, Backend APIs, Cloud Infrastructure, and DevOps',
    badge: 'Full Architecture',
    heroImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&w=1400&q=80',
    overview: 'Full Stack Development is the holistic mastery of entire software ecosystems: client-side user interfaces, server-side business logic, database persistence, caching layers, and automated cloud deployments. A modern full-stack developer seamlessly architects responsive React/Next.js interfaces, writes high-performance Node.js or Go services, optimizes SQL query plans, and secures infrastructure with Docker and CI/CD automation.',
    keyFeatures: [
      'Unified end-to-end architecture connecting reactive frontend to scalable backend',
      'Database modeling with relational (PostgreSQL) and document/key-value (Redis, MongoDB) stores',
      'Type-safe full-stack data sharing via TypeScript, tRPC, or GraphQL schema generation',
      'Containerization with Docker and deployment automation with GitHub Actions CI/CD',
      'Zero-trust security practices: CORS, CSRF tokens, SQL injection defense, and JWT auth',
      'Cloud deployment across Vercel, AWS, Google Cloud, and container orchestration engines'
    ],
    techStack: [
      { name: 'TypeScript', role: 'Full-Stack Language' },
      { name: 'React & Next.js', role: 'Frontend Architecture' },
      { name: 'Node.js & Express', role: 'Backend Services' },
      { name: 'PostgreSQL', role: 'Primary Relational Database' },
      { name: 'Redis', role: 'In-Memory Cache & PubSub' },
      { name: 'Docker', role: 'Container Isolation' }
    ],
    coreTopics: [
      { title: 'End-to-End Data Modeling', desc: 'Designing normalized database schemas and mapping them to type-safe client APIs.' },
      { title: 'Authentication & Session Architecture', desc: 'OAuth2, OpenID Connect, HTTP-only secure cookies, and session invalidation.' },
      { title: 'DevOps & Observability', desc: 'Structured logging, Prometheus metrics, Grafana dashboards, and automated deployment pipelines.' }
    ],
    learningResources: [
      { title: 'Full Stack Open', type: 'Course', url: 'https://fullstackopen.com/en/', desc: 'University of Helsinki’s legendary course on modern full stack web development.' }
    ],
    documentationLinks: [
      { title: 'PostgreSQL Documentation', url: 'https://www.postgresql.org/docs/', desc: 'The world’s most advanced open-source database manual.' }
    ],
    relatedRoutes: [
      { title: 'React Development', route: '/web-development/react', description: 'Master client-side application engineering.' },
      { title: 'Node.js Backend', route: '/web-development/nodejs', description: 'Deep-dive into server-side architectures.' },
      { title: 'Next.js Development', route: '/web-development/nextjs', description: 'Build full-stack applications with React.' }
    ]
  },

  // -------------------------------------------------------------
  // AI TOOLS & DEVELOPMENT
  // -------------------------------------------------------------
  'ai-development': {
    slug: 'ai-development',
    route: '/ai-development',
    parentCategory: 'AI Tools',
    parentHref: '#ai-tools',
    title: 'AI Tools & Development',
    subtitle: 'Supercharging Development with Generative AI, Agents, and LLM Workflows',
    tagline: 'Code Assistants, Neural Generation, LangChain, Prompt Engineering, and Automation',
    badge: 'Artificial Intelligence',
    heroImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1400&q=80',
    fallbackImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1400&q=80',
    overview: 'Artificial Intelligence is revolutionizing software engineering. Modern developers no longer write code in isolation; they orchestrate intelligent coding companions like GitHub Copilot, Cursor AI, and Claude 3.5 Sonnet to refactor legacy code, draft comprehensive unit tests, generate documentation, and automate repetitive workflows. Furthermore, integrating LLMs into web applications via LangChain, Vercel AI SDK, and Vector Databases opens up brand-new frontiers in automated intelligence.',
    keyFeatures: [
      'AI pair-programming integration (Cursor, GitHub Copilot, Supermaven) for 5x velocity',
      'Retrieval-Augmented Generation (RAG) using vector databases (Pinecone, pgvector)',
      'Autonomous agentic workflows capable of multi-step planning, tool use, and debugging',
      'Vercel AI SDK for streaming AI chat and structured generative JSON in web applications',
      'Prompt engineering techniques (Chain-of-Thought, ReAct, few-shot prompting)',
      'Local LLM inference deployment using Ollama and llama.cpp for total data privacy'
    ],
    techStack: [
      { name: 'Vercel AI SDK', role: 'Streaming UI & React Integration' },
      { name: 'LangChain / LlamaIndex', role: 'LLM Orchestration' },
      { name: 'Ollama', role: 'Local Private Model Execution' },
      { name: 'OpenAI / Anthropic APIs', role: 'State-of-the-Art Foundation Models' },
      { name: 'Pinecone / PgVector', role: 'High-Dimensional Vector Search' }
    ],
    coreTopics: [
      { title: 'Building Retrieval-Augmented Generation (RAG)', desc: 'Document chunking strategies, embedding generation, vector similarity search, and synthesized response generation.' },
      { title: 'Autonomous AI Agents', desc: 'Equipping models with executable tool declarations, stateful memory, and feedback loops.' },
      { title: 'Fine-Tuning vs In-Context Learning', desc: 'When to rely on targeted system prompts vs training LoRA adapters on custom datasets.' }
    ],
    learningResources: [
      { title: 'DeepLearning.AI Courses', type: 'Course', url: 'https://www.deeplearning.ai', desc: 'World-renowned short courses on LangChain, RAG, and AI agent architectures.' },
      { title: 'Hugging Face Learn', type: 'Interactive', url: 'https://huggingface.co/learn', desc: 'Interactive NLP and computer vision courses using open-source models.' }
    ],
    documentationLinks: [
      { title: 'Vercel AI SDK Docs', url: 'https://sdk.vercel.ai/docs', desc: 'The definitive library for building AI-powered React web applications.' },
      { title: 'OpenAI API Reference', url: 'https://platform.openai.com/docs', desc: 'Developer documentation for chat completions, embeddings, and vision models.' }
    ],
    relatedRoutes: [
      { title: 'Full Stack Development', route: '/web-development/fullstack', description: 'Deploy full-stack web applications with AI backends.' },
      { title: 'Python / System Tools', route: '/app-development/android', description: 'Connect AI endpoints to mobile and desktop clients.' }
    ]
  }
};

export const getCategoryBySlug = (slug: string): CategoryDetail | undefined => {
  return CATEGORIES_DATA[slug];
};

export const getCategoryByRoute = (route: string): CategoryDetail | undefined => {
  return Object.values(CATEGORIES_DATA).find((cat) => cat.route === route);
};
