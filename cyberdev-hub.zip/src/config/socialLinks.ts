// ============================================================
// Social Media & Developer Platform Links Configuration
// ============================================================
// Update the 'url' fields below with your own profile/community links.
// Set 'url' to '#' or empty string to disable a link.
// ============================================================

export interface SocialLink {
  name: string;
  url: string;
  icon: string; // react-icons identifier
  color: string;
  hoverColor: string;
  description: string;
}

export const socialLinks: SocialLink[] = [
  {
    name: 'GitHub',
    url: 'https://github.com',
    icon: 'FaGithub',
    color: '#ffffff',
    hoverColor: '#6e5494',
    description: 'Repositories & Open Source Projects',
  },
  {
    name: 'Telegram',
    url: 'https://telegram.org',
    icon: 'FaTelegram',
    color: '#26A5E4',
    hoverColor: '#0088cc',
    description: 'Join our developer community',
  },
  {
    name: 'Discord',
    url: 'https://discord.com',
    icon: 'FaDiscord',
    color: '#5865F2',
    hoverColor: '#4752C4',
    description: 'Real-time dev discussions',
  },
  {
    name: 'WhatsApp',
    url: 'https://whatsapp.com',
    icon: 'FaWhatsapp',
    color: '#25D366',
    hoverColor: '#128C7E',
    description: 'Quick dev support & chat',
  },
  {
    name: 'Instagram',
    url: 'https://instagram.com',
    icon: 'FaInstagram',
    color: '#E4405F',
    hoverColor: '#C13584',
    description: 'Dev tips & visual content',
  },
  {
    name: 'YouTube',
    url: 'https://youtube.com',
    icon: 'FaYoutube',
    color: '#FF0000',
    hoverColor: '#CC0000',
    description: 'Tutorials & coding videos',
  },
  {
    name: 'X (Twitter)',
    url: 'https://x.com',
    icon: 'FaXTwitter',
    color: '#ffffff',
    hoverColor: '#1DA1F2',
    description: 'Tech news & dev updates',
  },
  {
    name: 'LinkedIn',
    url: 'https://linkedin.com',
    icon: 'FaLinkedin',
    color: '#0A66C2',
    hoverColor: '#004182',
    description: 'Professional networking',
  },
  {
    name: 'Reddit',
    url: 'https://reddit.com',
    icon: 'FaReddit',
    color: '#FF4500',
    hoverColor: '#CC3700',
    description: 'Developer communities & discussions',
  },
  {
    name: 'Facebook',
    url: 'https://facebook.com',
    icon: 'FaFacebook',
    color: '#1877F2',
    hoverColor: '#0D65D9',
    description: 'Developer groups & pages',
  },
  {
    name: 'Stack Overflow',
    url: 'https://stackoverflow.com',
    icon: 'FaStackOverflow',
    color: '#F58025',
    hoverColor: '#D2691E',
    description: 'Q&A for developers',
  },
  {
    name: 'GitLab',
    url: 'https://gitlab.com',
    icon: 'FaGitlab',
    color: '#FC6D26',
    hoverColor: '#E24329',
    description: 'DevOps & CI/CD platform',
  },
  {
    name: 'Google Developers',
    url: 'https://developers.google.com',
    icon: 'FaGoogle',
    color: '#4285F4',
    hoverColor: '#34A853',
    description: 'Google APIs & developer tools',
  },
];

// Navigation links
export const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'App Development', href: '#app-dev' },
  { name: 'Web Development', href: '#web-dev' },
  { name: 'AI Tools', href: '#ai-tools' },
  { name: 'Resources', href: '#resources' },
  { name: 'About', href: '#about' },
  { name: 'Contact', href: '#contact' },
];
