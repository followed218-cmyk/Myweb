import { useState, useEffect } from 'react';
import { useTheme } from './hooks/useTheme';
import { RouterProvider, useRouter } from './context/RouterContext';
import { getCategoryByRoute } from './data/categoriesData';
import LoadingScreen from './components/LoadingScreen';
import ParticleBackground from './components/ParticleBackground';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AppDevelopment from './components/AppDevelopment';
import WebDevelopment from './components/WebDevelopment';
import AITools from './components/AITools';
import SocialConnect from './components/SocialConnect';
import Resources from './components/Resources';
import Footer from './components/Footer';
import SearchModal from './components/SearchModal';
import BackToTop from './components/BackToTop';
import CategoryDetailPage from './components/CategoryDetailPage';
import CyberCompanion from './components/CyberCompanion';

function AppContent() {
  const [loading, setLoading] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { currentPath } = useRouter();

  useEffect(() => {
    // Keyboard shortcut for search (Ctrl+K or Cmd+K)
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (loading) {
    return <LoadingScreen onComplete={() => setLoading(false)} />;
  }

  // Check if current URL matches a dedicated category detail page
  const categoryDetail = getCategoryByRoute(currentPath);

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : 'light'}`}>
      <ParticleBackground />
      <Navbar
        theme={theme}
        toggleTheme={toggleTheme}
        onSearchOpen={() => setSearchOpen(true)}
      />

      <main>
        {categoryDetail ? (
          <CategoryDetailPage category={categoryDetail} />
        ) : (
          <>
            <Hero />
            <AppDevelopment />
            <WebDevelopment />
            <AITools />
            <Resources />
            <SocialConnect />
          </>
        )}
      </main>

      <Footer />
      <SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
      <BackToTop />
      <CyberCompanion />
    </div>
  );
}

function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}

export default App;
