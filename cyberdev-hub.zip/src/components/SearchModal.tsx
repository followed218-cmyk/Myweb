import { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useRouter } from '../context/RouterContext';

export interface SearchItem {
  title: string;
  section: string;
  href: string;
}

export interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SEARCH_ITEMS: SearchItem[] = [
  // App Dev Dedicated Routes
  { title: 'Android App Development', section: 'App Dev', href: '/app-development/android' },
  { title: 'Kotlin Development', section: 'App Dev', href: '/app-development/kotlin' },
  { title: 'Java Development', section: 'App Dev', href: '/app-development/java' },
  { title: 'APK Reverse Engineering', section: 'App Dev', href: '/app-development/apk-reverse-engineering' },
  { title: 'APK Analysis & Security', section: 'App Dev', href: '/app-development/apk-analysis' },
  { title: 'App UI/UX Design', section: 'App Dev', href: '/app-development/app-ui-ux-design' },
  { title: 'Android Studio Mastery', section: 'App Dev', href: '/app-development/android-studio' },
  { title: 'Flutter Development', section: 'App Dev', href: '/app-development/flutter' },

  // Web Dev Dedicated Routes
  { title: 'HTML5 & Modern CSS3', section: 'Web Dev', href: '/web-development/html-css' },
  { title: 'JavaScript Development', section: 'Web Dev', href: '/web-development/javascript' },
  { title: 'React Development', section: 'Web Dev', href: '/web-development/react' },
  { title: 'Next.js Full Stack', section: 'Web Dev', href: '/web-development/nextjs' },
  { title: 'Node.js Backend Engineering', section: 'Web Dev', href: '/web-development/nodejs' },
  { title: 'Web Design & Creative UI', section: 'Web Dev', href: '/web-development/web-design' },
  { title: 'Full Stack Development', section: 'Web Dev', href: '/web-development/fullstack' },
  { title: 'AI Tools & Development', section: 'AI Tools', href: '/ai-development' },

  // Sections on Homepage
  { title: 'Hero & Terminal Initialization', section: 'Home', href: '#home' },
  { title: 'App Development Section', section: 'Sections', href: '#app-dev' },
  { title: 'Web Development Section', section: 'Sections', href: '#web-dev' },
  { title: 'AI Tools Directory', section: 'Sections', href: '#ai-tools' },
  { title: 'Developer Resources', section: 'Resources', href: '#resources' },
  { title: 'Connect & Social Platforms', section: 'Connect', href: '#about' },

  // AI Tools Directory entries
  { title: 'GitHub Copilot', section: 'AI Tools', href: '#ai-tools' },
  { title: 'Cursor AI Code Editor', section: 'AI Tools', href: '#ai-tools' },
  { title: 'Midjourney AI', section: 'AI Tools', href: '#ai-tools' },
  { title: 'Vercel AI SDK', section: 'AI Tools', href: '#ai-tools' },
  { title: 'FlutterFlow Builder', section: 'AI Tools', href: '#ai-tools' },
  { title: 'LangChain Orchestration', section: 'AI Tools', href: '#ai-tools' },

  // Resources
  { title: 'GitHub Repositories', section: 'Resources', href: '#resources' },
  { title: 'Open Source Projects', section: 'Resources', href: '#resources' },
  { title: 'Android Documentation', section: 'Resources', href: '#resources' },
  { title: 'Programming Tutorials', section: 'Resources', href: '#resources' },
  { title: 'APK Tools & Disassembly', section: 'Resources', href: '#resources' },
  { title: 'Developer APIs Directory', section: 'Resources', href: '#resources' },
];

const SearchModal = ({ isOpen, onClose }: SearchModalProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const { navigate } = useRouter();

  // Auto-focus input when modal opens
  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      const focusTimer = setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
      return () => clearTimeout(focusTimer);
    }
  }, [isOpen]);

  // Close on Escape key press
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  const trimmedQuery = searchQuery.trim().toLowerCase();

  const filteredItems = trimmedQuery === ''
    ? []
    : SEARCH_ITEMS.filter((item) =>
        item.title.toLowerCase().includes(trimmedQuery) ||
        item.section.toLowerCase().includes(trimmedQuery)
      );

  const handleItemClick = (href: string) => {
    onClose();
    navigate(href);
  };

  const getBadgeStyle = (section: string) => {
    switch (section.toLowerCase()) {
      case 'app dev':
        return 'bg-neon-500/10 text-neon-400 border-neon-500/30';
      case 'web dev':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'ai tools':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
      case 'resources':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      default:
        return 'bg-redAccent-500/10 text-redAccent-400 border-redAccent-500/30';
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center items-start px-4 overflow-y-auto"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="w-full max-w-2xl mt-16 sm:mt-24 mb-12 glass-card border border-neon-500/30 shadow-[0_0_35px_rgba(0,255,65,0.2)] rounded-2xl overflow-hidden search-overlay"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center px-4 py-3.5 border-b border-cyber-border">
          <Search className="w-5 h-5 text-neon-500 flex-shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search technologies, courses, tools, or topics..."
            className="w-full bg-transparent text-gray-100 placeholder-gray-500 text-base focus:outline-none font-sans"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="p-1 rounded-lg hover:bg-neon-500/10 text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="ml-2 p-1.5 rounded-lg hover:bg-neon-500/10 text-gray-400 hover:text-neon-500 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results List */}
        <div className="max-h-[60vh] overflow-y-auto">
          {trimmedQuery === '' ? (
            <div className="py-10 px-6 text-center text-gray-400">
              <p className="text-sm text-gray-300 font-medium">Type to search CyberDev Hub...</p>
              <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                {['Android', 'Kotlin', 'React', 'Reverse Engineering', 'Next.js', 'AI Tools'].map((keyword) => (
                  <button
                    key={keyword}
                    type="button"
                    onClick={() => setSearchQuery(keyword)}
                    className="px-2.5 py-1 rounded-lg text-xs font-mono bg-cyber-surface border border-cyber-border text-gray-300 hover:border-neon-500 hover:text-neon-400 transition-colors cursor-pointer"
                  >
                    {keyword}
                  </button>
                ))}
              </div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="py-12 px-6 text-center text-gray-400">
              <p className="text-base text-gray-300 font-medium">No results found</p>
              <p className="text-xs text-gray-500 mt-1">
                No matching results for &ldquo;{searchQuery}&rdquo;. Try another term.
              </p>
            </div>
          ) : (
            <div className="p-3">
              <div className="px-3 py-1.5 text-xs font-mono text-gray-400 uppercase tracking-wider flex items-center justify-between">
                <span>Results</span>
                <span>{filteredItems.length} found</span>
              </div>
              <ul className="space-y-1 mt-1">
                {filteredItems.map((item, index) => (
                  <li key={`${item.title}-${index}`}>
                    <button
                      type="button"
                      onClick={() => handleItemClick(item.href)}
                      className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-left text-gray-200 hover:text-white hover:bg-neon-500/10 border border-transparent hover:border-neon-500/30 transition-all duration-150 group cursor-pointer"
                    >
                      <span className="font-medium text-sm sm:text-base group-hover:text-neon-400 transition-colors">
                        {item.title}
                      </span>
                      <span
                        className={`ml-3 px-2.5 py-0.5 text-xs font-mono font-medium rounded-full border flex-shrink-0 ${getBadgeStyle(
                          item.section
                        )}`}
                      >
                        {item.section}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Modal Footer info */}
        <div className="px-4 py-2.5 border-t border-cyber-border bg-cyber-surface/40 flex items-center justify-between text-xs text-gray-500 font-mono">
          <div className="flex items-center gap-3">
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-cyber-bg border border-cyber-border text-gray-400 text-[10px]">
                ESC
              </kbd>{' '}
              to close
            </span>
          </div>
          <span className="text-neon-500/80">CyberDev Hub System</span>
        </div>
      </div>
    </div>
  );
};

export default SearchModal;
