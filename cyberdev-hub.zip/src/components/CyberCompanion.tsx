import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  Minus,
  Sparkles,
  Send,
  Smartphone,
  Globe,
  Bot,
  BookOpen,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';
import { useRouter } from '../context/RouterContext';

export type MascotState = 'IDLE' | 'HAPPY' | 'THINKING' | 'WELCOME' | 'LOADING' | 'SUCCESS';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  actionRoute?: string;
  actionText?: string;
  timestamp: string;
}

const DEFAULT_MESSAGES: Message[] = [
  {
    id: 'welcome-1',
    sender: 'bot',
    text: "Greetings developer! 👋 I'm CyberCore, your intelligent 3D companion. Looking for Android roadmaps, reverse engineering tools, modern web architectures, or AI tooling? Tap a prompt below or ask me anything!",
    timestamp: 'Just now',
  },
];

const SUGGESTED_QUESTIONS = [
  'How do I start Android development?',
  'What is APK reverse engineering?',
  'Which tools are useful for Kotlin?',
  'How can I build a website?',
];

const SPEECH_BUBBLES = [
  'Welcome to CyberDev Hub! 👋',
  'Need help with Android Development? 📱',
  "Let's build something awesome! ⚡",
  'Looking for developer tools? 🛠️',
  'Explore our latest resources! 🚀',
  'Check out APK Reverse Engineering! 🔓',
];

/**
 * Photorealistic 3D Metallic Purple Cyber Robot Mascot
 * Rendered with pure SVG: 100% transparent background, multi-layered volumetric lighting,
 * curved gloss visor, animated dynamic eyes, side cyber capsules, and pulsing reactor.
 */
interface RobotProps {
  state: MascotState;
  isBlinking: boolean;
  className?: string;
}

export const Robot3DCharacter: React.FC<RobotProps> = ({ state, isBlinking, className = '' }) => {
  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`w-full h-full select-none pointer-events-none drop-shadow-[0_8px_20px_rgba(147,51,234,0.45)] ${className}`}
      aria-label="CyberDev 3D AI Mascot"
    >
      <defs>
        {/* Volumetric Purple Metallic Shell Gradient */}
        <radialGradient
          id="shellMetallic"
          cx="38%"
          cy="32%"
          r="65%"
          fx="38%"
          fy="32%"
        >
          <stop offset="0%" stopColor="#e9d5ff" />
          <stop offset="22%" stopColor="#c084fc" />
          <stop offset="55%" stopColor="#7e22ce" />
          <stop offset="85%" stopColor="#4c1d95" />
          <stop offset="100%" stopColor="#1e0b38" />
        </radialGradient>

        {/* Ambient Dark Purple Rim Shadow */}
        <linearGradient id="rimShading" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
          <stop offset="40%" stopColor="#9333ea" stopOpacity="0" />
          <stop offset="100%" stopColor="#090214" stopOpacity="0.8" />
        </linearGradient>

        {/* Deep Curved Glass Visor Gradient */}
        <linearGradient id="visorGlass" x1="20%" y1="0%" x2="80%" y2="100%">
          <stop offset="0%" stopColor="#0b0818" />
          <stop offset="45%" stopColor="#150f28" />
          <stop offset="100%" stopColor="#04020a" />
        </linearGradient>

        {/* Visor Specular Arc Sheen */}
        <linearGradient id="visorArcGlare" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
          <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.1" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0" />
        </linearGradient>

        {/* Cyber Ear Pod Metallic Gradients */}
        <linearGradient id="earPodGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#d8b4fe" />
          <stop offset="50%" stopColor="#6b21a8" />
          <stop offset="100%" stopColor="#17062e" />
        </linearGradient>

        {/* Top Antenna Glowing Energy Core */}
        <radialGradient id="energyCore" cx="35%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="35%" stopColor="#00FF41" />
          <stop offset="75%" stopColor="#15803d" />
          <stop offset="100%" stopColor="#052e16" />
        </radialGradient>

        {/* Soft High-Tech Neon Glow Filters */}
        <filter id="neonEyeGlow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="1.8" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <filter id="coreGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3.5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ================= 1. FLOATING ANTENNA & ENERGY CORE ================= */}
      {/* Antenna Stalk */}
      <path
        d="M60 26 L60 14"
        stroke="#6b21a8"
        strokeWidth="3.5"
        strokeLinecap="round"
      />
      <path
        d="M60 26 L60 14"
        stroke="#d8b4fe"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      {/* Energy Core Orb with Pulse Ring */}
      <circle cx="60" cy="11" r="7" fill="url(#energyCore)" filter="url(#coreGlow)" />
      <circle cx="58" cy="9" r="2.2" fill="#ffffff" opacity="0.85" />
      <circle
        cx="60"
        cy="11"
        r="8.5"
        stroke="#00FF41"
        strokeWidth="1"
        opacity="0.6"
        strokeDasharray="2 2"
      />

      {/* ================= 2. SIDE CYBER EAR PODS ================= */}
      {/* Left Ear Capsule */}
      <g>
        <rect
          x="14"
          y="48"
          width="10"
          height="24"
          rx="5"
          fill="url(#earPodGrad)"
          stroke="#581c87"
          strokeWidth="1"
        />
        <rect
          x="18"
          y="54"
          width="3.5"
          height="12"
          rx="1.75"
          fill="#00FF41"
          filter="url(#neonEyeGlow)"
          opacity="0.85"
        />
      </g>

      {/* Right Ear Capsule */}
      <g>
        <rect
          x="96"
          y="48"
          width="10"
          height="24"
          rx="5"
          fill="url(#earPodGrad)"
          stroke="#581c87"
          strokeWidth="1"
        />
        <rect
          x="98.5"
          y="54"
          width="3.5"
          height="12"
          rx="1.75"
          fill="#00FF41"
          filter="url(#neonEyeGlow)"
          opacity="0.85"
        />
      </g>

      {/* ================= 3. 3D METALLIC HEAD / BODY CHASSIS ================= */}
      {/* Main 3D Spherical Head Form */}
      <rect
        x="20"
        y="24"
        width="80"
        height="74"
        rx="37"
        fill="url(#shellMetallic)"
      />
      {/* Ambient Rim Shading Overlay for Spherical Occlusion */}
      <rect
        x="20"
        y="24"
        width="80"
        height="74"
        rx="37"
        fill="url(#rimShading)"
      />
      {/* Top Specular Curved Highlight */}
      <ellipse
        cx="46"
        cy="33"
        rx="22"
        ry="7"
        fill="#ffffff"
        opacity="0.4"
        transform="rotate(-10 46 33)"
      />

      {/* ================= 4. CURVED HIGH-GLOSS VISOR ================= */}
      {/* Outer Visor Bezel */}
      <rect
        x="27"
        y="42"
        width="66"
        height="38"
        rx="19"
        fill="#05020a"
        stroke="#7e22ce"
        strokeWidth="1.5"
      />
      {/* Inner Visor Glass */}
      <rect
        x="29"
        y="44"
        width="62"
        height="34"
        rx="17"
        fill="url(#visorGlass)"
      />
      {/* Visor Arc Reflection (Realistic Glass Curvature) */}
      <path
        d="M33 53 C38 46 82 46 87 53 C82 49 38 49 33 53 Z"
        fill="url(#visorArcGlare)"
      />

      {/* ================= 5. DYNAMIC VISOR EYES / FACIAL DISPLAY ================= */}
      {state === 'HAPPY' || state === 'SUCCESS' ? (
        /* Happy Radiant Smiling Arc Eyes (^ ^) */
        <g filter="url(#neonEyeGlow)">
          <path
            d="M44 61 C47 53 53 53 56 61"
            stroke="#00FF41"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
          <path
            d="M64 61 C67 53 73 53 76 61"
            stroke="#00FF41"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
        </g>
      ) : isBlinking ? (
        /* Blinking Slit Eyes */
        <g filter="url(#neonEyeGlow)">
          <line
            x1="44"
            y1="59"
            x2="56"
            y2="59"
            stroke="#00FF41"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <line
            x1="64"
            y1="59"
            x2="76"
            y2="59"
            stroke="#00FF41"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </g>
      ) : state === 'THINKING' ? (
        /* Thinking High-Tech Cyan Radar Scanning Beam */
        <g>
          <line
            x1="36"
            y1="59"
            x2="84"
            y2="59"
            stroke="#22d3ee"
            strokeWidth="2.5"
            strokeLinecap="round"
            filter="url(#neonEyeGlow)"
          >
            <animate
              attributeName="opacity"
              values="0.4;1;0.4"
              dur="1.2s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="60" cy="59" r="4" fill="#00FF41" filter="url(#neonEyeGlow)">
            <animate
              attributeName="cx"
              values="44;76;44"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
        </g>
      ) : (
        /* Default IDLE: Expressive Luminous Oval Digital Eyes */
        <g filter="url(#neonEyeGlow)">
          {/* Left Eye */}
          <ellipse cx="49" cy="59" rx="5" ry="7" fill="#00FF41" />
          <circle cx="47.5" cy="56.5" r="1.8" fill="#ffffff" />
          {/* Right Eye */}
          <ellipse cx="71" cy="59" rx="5" ry="7" fill="#00FF41" />
          <circle cx="69.5" cy="56.5" r="1.8" fill="#ffffff" />
        </g>
      )}

      {/* ================= 6. LOWER TORSO ACCENT & ARC REACTOR ================= */}
      {/* Lower Chassis Seam */}
      <path
        d="M40 86 Q60 92 80 86"
        stroke="#4c1d95"
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
      />
      {/* Glowing Hexagonal Arc Reactor */}
      <g filter="url(#coreGlow)">
        <polygon
          points="60,88 65,91 65,97 60,100 55,97 55,91"
          fill="#00FF41"
          opacity="0.9"
        />
        <polygon
          points="60,90 63,92 63,96 60,98 57,96 57,92"
          fill="#ffffff"
          opacity="0.75"
        />
      </g>
    </svg>
  );
};

export const CyberCompanion: React.FC = () => {
  const { currentPath, navigate } = useRouter();

  // Assistant & Panel State
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('cybercompanion_minimized') === 'true';
    }
    return false;
  });

  const [mascotState, setMascotState] = useState<MascotState>('IDLE');
  const [bubbleText, setBubbleText] = useState<string>('Welcome to CyberDev Hub! 👋');
  const [isBubbleVisible, setIsBubbleVisible] = useState<boolean>(false);
  const [bubbleAlignment, setBubbleAlignment] = useState<'left' | 'right' | 'top' | 'bottom'>('top');
  const [isBlinking, setIsBlinking] = useState<boolean>(false);

  // Chat conversation state
  const [messages, setMessages] = useState<Message[]>(DEFAULT_MESSAGES);
  const [inputVal, setInputVal] = useState<string>('');
  const [isThinking, setIsThinking] = useState<boolean>(false);

  // References for Ultra-Smooth Dragging (Zero React re-renders during active drag)
  const containerRef = useRef<HTMLDivElement>(null);
  const posRef = useRef<{ x: number; y: number }>({ x: 300, y: 500 });
  const velRef = useRef<{ vx: number; vy: number }>({ vx: 0, vy: 0 });
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ pointerX: number; pointerY: number; posX: number; posY: number; time: number }>({
    pointerX: 0,
    pointerY: 0,
    posX: 0,
    posY: 0,
    time: 0,
  });
  const lastSampleRef = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 });
  const rafIdRef = useRef<number | null>(null);
  const tapHistoryRef = useRef<number[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Character dimensions calculation
  const getCharacterDimensions = useCallback(() => {
    if (typeof window === 'undefined') return { width: 112, height: 112 };
    const isMobile = window.innerWidth < 640;
    return {
      width: isMobile ? 84 : 112,
      height: isMobile ? 84 : 112,
    };
  }, []);

  // Default positioning helper (Bottom-Right floating corner)
  const getDefaultPosition = useCallback(() => {
    if (typeof window !== 'undefined') {
      const { width, height } = getCharacterDimensions();
      const maxX = Math.max(12, window.innerWidth - width - 20);
      const maxY = Math.max(72, window.innerHeight - height - 32);
      return { x: maxX, y: maxY };
    }
    return { x: 300, y: 500 };
  }, [getCharacterDimensions]);

  // Clamping helper to prevent mascot from escaping screen
  const clampCoordinates = useCallback((x: number, y: number) => {
    if (typeof window === 'undefined') return { x, y };
    const { width, height } = getCharacterDimensions();
    const minX = 12;
    const maxX = Math.max(12, window.innerWidth - width - 12);
    const minY = 68; // Clear top navigation bar
    const maxY = Math.max(72, window.innerHeight - height - 16);
    return {
      x: Math.min(Math.max(minX, x), maxX),
      y: Math.min(Math.max(minY, y), maxY),
    };
  }, [getCharacterDimensions]);

  // Update bubble alignment based on mascot position relative to screen edges
  const updateBubbleAlignment = useCallback((x: number, y: number) => {
    if (typeof window === 'undefined') return;
    if (y < 150) {
      setBubbleAlignment('bottom');
    } else if (x > window.innerWidth - 220) {
      setBubbleAlignment('left');
    } else if (x < 200) {
      setBubbleAlignment('right');
    } else {
      setBubbleAlignment('top');
    }
  }, []);

  // Initialize position from localStorage or default
  useEffect(() => {
    let initialPos = getDefaultPosition();
    try {
      const saved = localStorage.getItem('cybercompanion_pos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.x === 'number' && typeof parsed.y === 'number') {
          initialPos = clampCoordinates(parsed.x, parsed.y);
        }
      }
    } catch (e) {
      // Use default
    }

    posRef.current = initialPos;
    if (containerRef.current) {
      containerRef.current.style.transform = `translate3d(${initialPos.x}px, ${initialPos.y}px, 0)`;
    }
    updateBubbleAlignment(initialPos.x, initialPos.y);
  }, [clampCoordinates, getDefaultPosition, updateBubbleAlignment]);

  // Window resize handler: re-clamp position
  useEffect(() => {
    const handleResize = () => {
      const clamped = clampCoordinates(posRef.current.x, posRef.current.y);
      posRef.current = clamped;
      if (containerRef.current) {
        containerRef.current.style.transform = `translate3d(${clamped.x}px, ${clamped.y}px, 0)`;
      }
      updateBubbleAlignment(clamped.x, clamped.y);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [clampCoordinates, updateBubbleAlignment]);

  // Auto-scroll chat messages
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isThinking]);

  // Natural Eye Blinking loop
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 180);
    }, 4500);

    return () => clearInterval(blinkInterval);
  }, []);

  // Contextual Speech Bubbles timer
  useEffect(() => {
    const initialTimer = setTimeout(() => {
      setBubbleText('Welcome to CyberDev Hub! 👋');
      setIsBubbleVisible(true);
      setTimeout(() => setIsBubbleVisible(false), 5500);
    }, 3000);

    const interval = setInterval(() => {
      if (!isOpen && !isMinimized && !isDraggingRef.current) {
        let msg = SPEECH_BUBBLES[Math.floor(Math.random() * SPEECH_BUBBLES.length)];
        if (currentPath.includes('android')) {
          msg = 'Mastering Jetpack Compose? Tap me for tips! 🤖';
        } else if (currentPath.includes('apk')) {
          msg = 'Need help decompiling with JADX or Apktool? 🔓';
        } else if (currentPath.includes('web')) {
          msg = 'Building with React & Tailwind? Ask me anything! 🌐';
        }
        setBubbleText(msg);
        setIsBubbleVisible(true);
        setTimeout(() => setIsBubbleVisible(false), 5500);
      }
    }, 32000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [isOpen, isMinimized, currentPath]);

  // Save minimized state
  useEffect(() => {
    localStorage.setItem('cybercompanion_minimized', isMinimized ? 'true' : 'false');
  }, [isMinimized]);

  // Clean up RAF on unmount
  useEffect(() => {
    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, []);

  // -------------------------------------------------------------
  // Ultra-Smooth Dragging Physics & Pointer Events API
  // -------------------------------------------------------------
  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;

    if (rafIdRef.current) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }

    isDraggingRef.current = true;
    const now = performance.now();

    dragStartRef.current = {
      pointerX: e.clientX,
      pointerY: e.clientY,
      posX: posRef.current.x,
      posY: posRef.current.y,
      time: now,
    };

    lastSampleRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: now,
    };

    velRef.current = { vx: 0, vy: 0 };

    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch (err) {
      // Not supported in this runtime
    }
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;

    const deltaX = e.clientX - dragStartRef.current.pointerX;
    const deltaY = e.clientY - dragStartRef.current.pointerY;

    // Track instantaneous velocity
    const now = performance.now();
    const dt = Math.max(1, now - lastSampleRef.current.time);
    velRef.current = {
      vx: ((e.clientX - lastSampleRef.current.x) / dt) * 16,
      vy: ((e.clientY - lastSampleRef.current.y) / dt) * 16,
    };
    lastSampleRef.current = { x: e.clientX, y: e.clientY, time: now };

    // Direct hardware-accelerated transform update without React re-render!
    const targetX = dragStartRef.current.posX + deltaX;
    const targetY = dragStartRef.current.posY + deltaY;
    const clamped = clampCoordinates(targetX, targetY);

    posRef.current = clamped;
    if (containerRef.current) {
      containerRef.current.style.transform = `translate3d(${clamped.x}px, ${clamped.y}px, 0)`;
    }
  };

  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;

    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch (err) {
      // Ignore
    }

    const dist = Math.hypot(
      e.clientX - dragStartRef.current.pointerX,
      e.clientY - dragStartRef.current.pointerY
    );
    const duration = performance.now() - dragStartRef.current.time;

    // TAP / CLICK DETECTION: If movement < 6px and duration < 350ms
    if (dist < 6 && duration < 350) {
      const now = Date.now();
      const recentTaps = tapHistoryRef.current.filter((t) => now - t < 380);
      recentTaps.push(now);
      tapHistoryRef.current = recentTaps;

      // DOUBLE TAP: Reset to default position
      if (recentTaps.length >= 2) {
        tapHistoryRef.current = [];
        resetToDefaultPosition();
        return;
      }

      // SINGLE TAP: Toggle assistant panel
      setIsOpen((prev) => !prev);
      setIsBubbleVisible(false);
      setMascotState('HAPPY');
      setTimeout(() => setMascotState('IDLE'), 1800);
      return;
    }

    // DRAGGED: Run Natural Momentum & Soft-Settle Physics Loop
    runMomentumPhysics();
  };

  const runMomentumPhysics = () => {
    const stepPhysics = () => {
      let { vx, vy } = velRef.current;

      // Subtle friction decay
      vx *= 0.88;
      vy *= 0.88;
      velRef.current = { vx, vy };

      let nextX = posRef.current.x + vx;
      let nextY = posRef.current.y + vy;

      const { width, height } = getCharacterDimensions();
      const minX = 12;
      const maxX = Math.max(12, window.innerWidth - width - 12);
      const minY = 68;
      const maxY = Math.max(72, window.innerHeight - height - 16);

      // Soft boundary dampening
      if (nextX < minX) {
        nextX = minX;
        velRef.current.vx *= -0.25;
      } else if (nextX > maxX) {
        nextX = maxX;
        velRef.current.vx *= -0.25;
      }

      if (nextY < minY) {
        nextY = minY;
        velRef.current.vy *= -0.25;
      } else if (nextY > maxY) {
        nextY = maxY;
        velRef.current.vy *= -0.25;
      }

      posRef.current = { x: nextX, y: nextY };
      if (containerRef.current) {
        containerRef.current.style.transform = `translate3d(${nextX}px, ${nextY}px, 0)`;
      }

      // Continue momentum until speed settles
      if (Math.hypot(vx, vy) > 0.3) {
        rafIdRef.current = requestAnimationFrame(stepPhysics);
      } else {
        rafIdRef.current = null;
        updateBubbleAlignment(posRef.current.x, posRef.current.y);
        try {
          localStorage.setItem(
            'cybercompanion_pos',
            JSON.stringify({ x: Math.round(posRef.current.x), y: Math.round(posRef.current.y) })
          );
        } catch (e) {
          // Ignore
        }
      }
    };

    rafIdRef.current = requestAnimationFrame(stepPhysics);
  };

  const resetToDefaultPosition = useCallback(() => {
    const defaultPos = getDefaultPosition();
    posRef.current = defaultPos;
    if (containerRef.current) {
      containerRef.current.style.transition = 'transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
      containerRef.current.style.transform = `translate3d(${defaultPos.x}px, ${defaultPos.y}px, 0)`;
      setTimeout(() => {
        if (containerRef.current) {
          containerRef.current.style.transition = '';
        }
      }, 400);
    }
    updateBubbleAlignment(defaultPos.x, defaultPos.y);
    try {
      localStorage.setItem('cybercompanion_pos', JSON.stringify(defaultPos));
    } catch (e) {
      // Ignore
    }
  }, [getDefaultPosition, updateBubbleAlignment]);

  // -------------------------------------------------------------
  // Conversational Logic Engine
  // -------------------------------------------------------------
  const getBotResponse = (query: string): { text: string; actionRoute?: string; actionText?: string } => {
    const q = query.toLowerCase();

    if (q.includes('android') || q.includes('kotlin') || q.includes('jetpack') || q.includes('mobile')) {
      return {
        text: 'For Android development, start with Kotlin fundamentals and modern Jetpack Compose for declarative UI. Explore our dedicated Android track to see architectures, MVVM patterns, and production sample projects.',
        actionRoute: '/app-development/android',
        actionText: 'Open Android Track →',
      };
    }

    if (q.includes('apk') || q.includes('reverse') || q.includes('decompile') || q.includes('jadx') || q.includes('security')) {
      return {
        text: 'APK Reverse Engineering requires tools like JADX-GUI, Apktool, and Frida for dynamic inspection. Check out our in-depth guides covering bytecode decompilation and security audits.',
        actionRoute: '/app-development/apk-reverse-engineering',
        actionText: 'Explore APK Reverse Engineering →',
      };
    }

    if (q.includes('flutter') || q.includes('cross-platform') || q.includes('dart')) {
      return {
        text: 'Flutter allows building smooth 60fps applications across Android and iOS from a single Dart codebase. Check our Flutter guide for state management and native bridge integration.',
        actionRoute: '/app-development/flutter',
        actionText: 'View Flutter Guide →',
      };
    }

    if (q.includes('web') || q.includes('website') || q.includes('react') || q.includes('html') || q.includes('frontend')) {
      return {
        text: 'Our Web Development tracks cover everything from modern semantic HTML & CSS to advanced React with TypeScript, Vite, Tailwind CSS, and server-side frameworks.',
        actionRoute: '/web-development/react',
        actionText: 'Explore React Track →',
      };
    }

    if (q.includes('ai') || q.includes('tool') || q.includes('copilot') || q.includes('gpt')) {
      return {
        text: 'Our AI Tools directory showcases industry-leading coding companions (GitHub Copilot, Cursor AI), generative UI creators, and LLM development frameworks like Vercel AI SDK and LangChain.',
        actionRoute: '#ai-tools',
        actionText: 'Browse AI Tools →',
      };
    }

    if (q.includes('resource') || q.includes('cheat') || q.includes('download') || q.includes('guide')) {
      return {
        text: 'You can access curated developer roadmaps, cheat sheets, terminal shortcuts, and recommended open-source repositories directly in our Resources section.',
        actionRoute: '#resources',
        actionText: 'View Developer Resources →',
      };
    }

    return {
      text: "I'm ready to help you level up your engineering skills! Select a topic from the quick shortcuts above or ask specifically about Android development, APK analysis, web architectures, or AI tooling.",
      actionRoute: '/app-development/android',
      actionText: 'Explore Developer Tracks →',
    };
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputVal).trim();
    if (!text) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsThinking(true);
    setMascotState('THINKING');

    setTimeout(() => {
      const response = getBotResponse(text);
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: response.text,
        actionRoute: response.actionRoute,
        actionText: response.actionText,
        timestamp: 'Just now',
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsThinking(false);
      setMascotState('SUCCESS');
      setTimeout(() => setMascotState('IDLE'), 2000);
    }, 550);
  };

  // Helper for speech bubble placement classes
  const getBubblePlacementClasses = () => {
    switch (bubbleAlignment) {
      case 'left':
        return 'right-full mr-3 top-1/2 -translate-y-1/2';
      case 'right':
        return 'left-full ml-3 top-1/2 -translate-y-1/2';
      case 'bottom':
        return 'top-full mt-3 left-1/2 -translate-x-1/2';
      case 'top':
      default:
        return 'bottom-full mb-3 left-1/2 -translate-x-1/2';
    }
  };

  return (
    <>
      {/* ===================== FLOATING 3D CHARACTER & SPEECH BUBBLE ===================== */}
      <div
        ref={containerRef}
        style={{
          touchAction: 'none',
          userSelect: 'none',
          WebkitUserSelect: 'none',
        }}
        className="fixed top-0 left-0 z-40 will-change-transform"
      >
        {/* Smart Directional Speech Bubble */}
        {isBubbleVisible && !isOpen && !isMinimized && (
          <div
            onClick={() => {
              setIsOpen(true);
              setIsBubbleVisible(false);
            }}
            className={`absolute ${getBubblePlacementClasses()} w-52 sm:w-60 p-3.5 rounded-2xl glass border border-purple-500/50 shadow-[0_0_25px_rgba(139,92,246,0.4),0_0_12px_rgba(0,255,65,0.2)] cursor-pointer animate-bubble-pop text-center group z-50`}
          >
            <p className="text-xs font-semibold text-white leading-relaxed">
              {bubbleText}
            </p>
            <span className="text-[10px] text-neon-400 font-mono mt-1.5 flex items-center justify-center gap-1 group-hover:text-neon-300">
              <span>Tap to chat</span>
              <Sparkles className="w-3 h-3 text-neon-400" />
            </span>
          </div>
        )}

        {/* Mascot Interactive Container (Transparent, No Box, No Frame) */}
        {!isMinimized ? (
          <div
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            className="relative cursor-grab active:cursor-grabbing group p-0 select-none"
            title="CyberDev AI Companion (Drag to move • Double-tap to reset • Tap to chat)"
            style={{ touchAction: 'none' }}
          >
            {/* Ambient Holographic Orbiting Particles (No bounding box) */}
            <div className="absolute top-0 right-2 w-2 h-2 rounded-full bg-neon-400 animate-mascot-sparkle shadow-[0_0_10px_#00FF41] pointer-events-none" />
            <div
              className="absolute bottom-2 left-1 w-1.5 h-1.5 rounded-full bg-purple-400 animate-mascot-sparkle shadow-[0_0_8px_#c084fc] pointer-events-none"
              style={{ animationDelay: '1.1s' }}
            />
            <div
              className="absolute top-1/2 -right-1 w-1.5 h-1.5 rounded-full bg-cyan-300 animate-mascot-sparkle shadow-[0_0_8px_#22d3ee] pointer-events-none"
              style={{ animationDelay: '0.6s' }}
            />

            {/* Pure 3D Floating Character - Desktop: ~112px, Mobile: ~84px */}
            <div className="relative w-[84px] h-[84px] sm:w-[112px] sm:h-[112px] animate-mascot-float flex items-center justify-center transition-transform duration-200 group-hover:scale-105">
              {/* Soft Ambient Radial Backlight Glow (No rectangular frame!) */}
              <div className="absolute inset-1 rounded-full bg-purple-600/30 blur-xl group-hover:bg-purple-500/45 transition-colors pointer-events-none" />

              {/* High-Quality 3D Vector Mascot */}
              <Robot3DCharacter state={mascotState} isBlinking={isBlinking} />
            </div>

            {/* Dynamic 3D Floor Shadow */}
            <div className="w-14 sm:w-18 h-2 sm:h-2.5 mx-auto bg-black/60 rounded-full blur-[2px] animate-mascot-shadow pointer-events-none mt-0.5" />
          </div>
        ) : (
          /* Minimized State: Sleek Glowing Cyber Pill */
          <button
            type="button"
            onClick={() => setIsMinimized(false)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full glass border border-purple-500/60 text-purple-200 hover:text-white shadow-[0_0_20px_rgba(139,92,246,0.6)] cursor-pointer group transition-all"
            title="Restore CyberCompanion"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-neon-500 animate-ping" />
            <span className="text-xs font-mono font-bold tracking-wider">CyberCore AI</span>
            <Sparkles className="w-3.5 h-3.5 text-neon-400 group-hover:rotate-12 transition-transform" />
          </button>
        )}
      </div>

      {/* ===================== SEPARATE AI ASSISTANT OVERLAY ===================== */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md"
          onClick={() => setIsOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-[#0c0d16]/95 border border-purple-500/40 shadow-[0_0_50px_rgba(139,92,246,0.3),0_0_25px_rgba(0,255,65,0.15)] rounded-2xl overflow-hidden flex flex-col h-[560px] max-h-[88vh] animate-bubble-pop backdrop-blur-xl"
          >
            {/* Panel Header */}
            <div className="px-4 py-3.5 bg-cyber-surface/90 border-b border-cyber-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative w-9 h-9 rounded-xl overflow-hidden border border-purple-500/50 shadow-[0_0_12px_rgba(139,92,246,0.5)] bg-[#120824] flex items-center justify-center p-0.5">
                  <Robot3DCharacter state={mascotState} isBlinking={false} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
                    <span>CyberCore AI</span>
                    <span className="flex items-center gap-1 text-[10px] text-neon-400 font-normal">
                      <span className="w-2 h-2 rounded-full bg-neon-500 inline-block animate-pulse" />
                      Online
                    </span>
                  </h3>
                  <p className="text-[10px] text-gray-400 font-mono">CyberDev Hub Engineering Assistant</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                {/* Reset Mascot Position Button */}
                <button
                  type="button"
                  onClick={resetToDefaultPosition}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-neon-400 hover:bg-white/10 transition-colors"
                  title="Reset mascot position to default"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                {/* Minimize Button */}
                <button
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    setIsMinimized(true);
                  }}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                  title="Minimize assistant"
                >
                  <Minus className="w-4 h-4" />
                </button>
                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-redAccent-400 hover:bg-white/10 transition-colors"
                  title="Close Assistant"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Category Action Chips */}
            <div className="px-3.5 py-2.5 bg-cyber-deep/80 border-b border-cyber-border flex items-center gap-2 overflow-x-auto text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate('/app-development/android');
                }}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyber-card border border-neon-500/30 text-gray-200 hover:text-neon-400 hover:border-neon-500 transition-colors cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5 text-neon-500" />
                <span>Android</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate('/web-development/html-css');
                }}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyber-card border border-blue-500/30 text-gray-200 hover:text-blue-400 hover:border-blue-500 transition-colors cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <span>Web Dev</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate('#ai-tools');
                }}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyber-card border border-purple-500/30 text-gray-200 hover:text-purple-400 hover:border-purple-500 transition-colors cursor-pointer"
              >
                <Bot className="w-3.5 h-3.5 text-purple-400" />
                <span>AI Tools</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate('#resources');
                }}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyber-card border border-amber-500/30 text-gray-200 hover:text-amber-400 hover:border-amber-500 transition-colors cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Resources</span>
              </button>
            </div>

            {/* Chat Conversation Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    msg.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-gradient-to-r from-purple-700 to-purple-600 text-white rounded-br-none shadow-[0_0_15px_rgba(139,92,246,0.35)]'
                        : 'bg-cyber-surface border border-cyber-border text-gray-200 rounded-bl-none shadow-sm'
                    }`}
                  >
                    <p>{msg.text}</p>

                    {/* Action Route Navigation Button */}
                    {msg.actionRoute && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsOpen(false);
                          navigate(msg.actionRoute!);
                        }}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neon-500/15 border border-neon-500/40 text-neon-400 hover:text-neon-300 hover:bg-neon-500/25 text-xs font-semibold tracking-wide transition-all cursor-pointer"
                      >
                        <span>{msg.actionText || 'Explore Track'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <span className="text-[10px] text-gray-500 font-mono mt-1 px-1">
                    {msg.timestamp}
                  </span>
                </div>
              ))}

              {/* Thinking / Typing Animation */}
              {isThinking && (
                <div className="flex items-center gap-2 p-3 rounded-2xl bg-cyber-surface border border-cyber-border w-28 rounded-bl-none">
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" />
                  <span
                    className="w-2 h-2 rounded-full bg-neon-400 animate-bounce"
                    style={{ animationDelay: '0.15s' }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-redAccent-400 animate-bounce"
                    style={{ animationDelay: '0.3s' }}
                  />
                  <span className="text-[10px] text-gray-400 font-mono ml-1">Thinking</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Questions Grid */}
            <div className="px-4 pt-2.5 pb-2 border-t border-cyber-border/50 bg-cyber-surface/40">
              <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block mb-1.5">
                Suggested Prompts
              </span>
              <div className="flex flex-wrap gap-1.5">
                {SUGGESTED_QUESTIONS.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendMessage(q)}
                    className="text-[11px] px-2.5 py-1 rounded-full bg-cyber-card border border-cyber-border text-gray-300 hover:text-neon-400 hover:border-neon-500/40 transition-colors text-left cursor-pointer"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Bar */}
            <div className="p-3.5 border-t border-cyber-border bg-cyber-surface flex items-center gap-2">
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ask CyberCore anything about dev tracks, tools or roadmaps..."
                className="flex-1 bg-cyber-card border border-cyber-border rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-purple-500 font-sans transition-colors"
              />
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputVal.trim() || isThinking}
                className="w-10 h-10 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:hover:bg-purple-600 text-white flex items-center justify-center transition-all cursor-pointer shadow-[0_0_15px_rgba(139,92,246,0.5)] flex-shrink-0"
                title="Send Message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CyberCompanion;
