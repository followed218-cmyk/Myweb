import React, { useMemo } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  opacity: number;
  delay: number;
}

const ParticleBackground: React.FC = () => {
  // Generate 30 particles with random positions, sizes (1-3px), and animation delays
  const particles = useMemo<Particle[]>(() => {
    return Array.from({ length: 30 }, (_, index) => ({
      id: index,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1,
      opacity: Number((Math.random() * 0.4 + 0.4).toFixed(2)),
      delay: Number((Math.random() * 20).toFixed(2)),
    }));
  }, []);

  return (
    <div
      className="fixed inset-0 pointer-events-none overflow-hidden z-0"
      aria-hidden="true"
    >
      {/* Full-screen hacker.jpg background with dark overlay */}
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-500 opacity-30 dark:opacity-40"
        style={{ backgroundImage: "url('/hacker.jpg')" }}
      />
      <div className="fixed inset-0 bg-cyber-bg/85 dark:bg-black/80 backdrop-blur-[1px]" />

      {/* Subtle grid overlay */}
      <div className="cyber-grid fixed inset-0 pointer-events-none" />

      {/* Horizontal scanning line effect */}
      <div className="scan-line fixed pointer-events-none" />

      {/* Floating particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full animate-particle pointer-events-none"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            backgroundColor: `rgba(0, 255, 65, ${particle.opacity})`,
            animationDelay: `${particle.delay}s`,
          }}
        />
      ))}
    </div>
  );
};

export default ParticleBackground;
