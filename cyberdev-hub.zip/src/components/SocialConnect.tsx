import React, { useState } from 'react';
import { ExternalLink } from 'lucide-react';
import {
  FaGithub,
  FaTelegram,
  FaDiscord,
  FaWhatsapp,
  FaInstagram,
  FaYoutube,
  FaXTwitter,
  FaLinkedin,
  FaReddit,
  FaFacebook,
  FaStackOverflow,
  FaGitlab,
  FaGoogle,
} from 'react-icons/fa6';
import { socialLinks, type SocialLink } from '../config/socialLinks';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const iconMap: Record<string, React.ComponentType<{size?: number; className?: string}>> = {
  FaGithub,
  FaTelegram,
  FaDiscord,
  FaWhatsapp,
  FaInstagram,
  FaYoutube,
  FaXTwitter,
  FaLinkedin,
  FaReddit,
  FaFacebook,
  FaStackOverflow,
  FaGitlab,
  FaGoogle,
};

interface SocialCardProps {
  link: SocialLink;
}

const SocialCard: React.FC<SocialCardProps> = ({ link }) => {
  const [isHovered, setIsHovered] = useState(false);
  const IconComponent = iconMap[link.icon];

  return (
    <a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
      className="glass-card scroll-animate p-4 text-center relative group flex flex-col items-center justify-center transition-all duration-300"
      style={{
        borderColor: isHovered ? link.color : undefined,
        boxShadow: isHovered
          ? `0 0 20px ${link.color}50, 0 8px 32px rgba(0, 0, 0, 0.3)`
          : undefined,
      }}
    >
      <ExternalLink
        size={14}
        className="absolute top-3 right-3 text-gray-500 group-hover:text-gray-300 transition-colors"
      />
      <div
        className="flex items-center justify-center transition-colors duration-300 text-gray-400"
        style={{ color: isHovered ? link.color : undefined }}
      >
        {IconComponent && <IconComponent size={32} className="mx-auto" />}
      </div>
      <h3 className="font-semibold mt-2 text-white">
        {link.name}
      </h3>
      <p className="text-xs text-gray-400 mt-1">
        {link.description}
      </p>
    </a>
  );
};

const SocialConnect: React.FC = () => {
  const containerRef = useScrollAnimation();

  return (
    <section id="about" className="py-20 px-4 max-w-7xl mx-auto">
      <h2 className="section-title">Connect With Us</h2>
      <p className="text-gray-400 text-center mb-12">
        Join our developer community across platforms
      </p>
      <div
        ref={containerRef}
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
      >
        {socialLinks.map((link) => (
          <SocialCard key={link.name} link={link} />
        ))}
      </div>
    </section>
  );
};

export default SocialConnect;
