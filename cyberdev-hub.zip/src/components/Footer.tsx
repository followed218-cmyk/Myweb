import React from 'react';
import { Mail, MapPin, Heart, ArrowUpRight } from 'lucide-react';
import { FaGithub, FaTelegram, FaDiscord, FaYoutube } from 'react-icons/fa6';
import { socialLinks as configuredSocialLinks } from '../config/socialLinks';
import SiteLogo from './SiteLogo';

const quickLinks = [
  { name: 'Home', href: '#home' },
  { name: 'App Development', href: '#app-dev' },
  { name: 'Web Development', href: '#web-dev' },
  { name: 'AI Tools', href: '#ai-tools' },
  { name: 'Resources', href: '#resources' },
];

const resourceLinks = [
  'GitHub Repos',
  'Documentation',
  'Tutorials',
  'API Reference',
  'Developer Tools',
];

const getSocialUrl = (name: string, fallback: string) => {
  return configuredSocialLinks.find((s) => s.name.toLowerCase() === name.toLowerCase())?.url || fallback;
};

const footerSocialLinks = [
  { name: 'GitHub', icon: FaGithub, href: getSocialUrl('GitHub', 'https://github.com') },
  { name: 'Telegram', icon: FaTelegram, href: getSocialUrl('Telegram', 'https://telegram.org') },
  { name: 'Discord', icon: FaDiscord, href: getSocialUrl('Discord', 'https://discord.com') },
  { name: 'YouTube', icon: FaYoutube, href: getSocialUrl('YouTube', 'https://youtube.com') },
];

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="glass bg-cyber-bg/95 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Main 4-column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1 - Branding */}
          <div className="flex flex-col">
            <SiteLogo
              size="md"
              showText={true}
              clickable={true}
              withGlow={true}
            />
            <p className="text-gray-400 text-sm leading-relaxed mt-4">
              Your gateway to modern development, AI innovation, and digital mastery.
            </p>
            <div className="flex items-center gap-3 mt-6">
              {footerSocialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.name}
                    className="w-9 h-9 rounded-lg bg-cyber-surface border border-cyber-border flex items-center justify-center text-gray-400 hover:text-neon hover:border-neon/40 hover:shadow-[0_0_12px_rgba(0,255,65,0.2)] transition-all duration-300"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Column 2 - Quick Links */}
          <div>
            <h4 className="text-white font-mono font-semibold text-lg mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-neon transition-colors duration-200 text-sm inline-flex items-center gap-1 group"
                  >
                    <span className="group-hover:translate-x-1 transition-transform duration-200">
                      {link.name}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3 - Resources */}
          <div>
            <h4 className="text-white font-mono font-semibold text-lg mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5">
              {resourceLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#resources"
                    className="text-gray-400 hover:text-neon transition-colors duration-200 text-sm inline-flex items-center gap-1 group"
                  >
                    <span className="group-hover:translate-x-1 transition-transform duration-200">
                      {link}
                    </span>
                    <ArrowUpRight className="w-3.5 h-3.5 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-neon" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4 - Contact */}
          <div>
            <h4 className="text-white font-mono font-semibold text-lg mb-4">
              Contact
            </h4>
            <div className="space-y-3">
              <a
                href="mailto:hello@cyberdevhub.com"
                className="flex items-center gap-3 text-sm text-gray-400 hover:text-neon transition-colors group"
              >
                <div className="w-8 h-8 rounded-lg bg-cyber-surface border border-cyber-border flex items-center justify-center text-neon shrink-0 group-hover:border-neon/40 transition-colors">
                  <Mail className="w-4 h-4" />
                </div>
                <span className="break-all">hello@cyberdevhub.com</span>
              </a>

              <div className="flex items-center gap-3 text-sm text-gray-400">
                <div className="w-8 h-8 rounded-lg bg-cyber-surface border border-cyber-border flex items-center justify-center text-neon shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <span>Digital World, Internet</span>
              </div>

              <p className="text-sm text-gray-400 pt-2 leading-relaxed">
                Have questions? Reach out to us through our social channels.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-neon/10 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
          <p>© 2024 CyberDev Hub. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built with ⚡ by CyberDev Hub
            <Heart className="w-3.5 h-3.5 text-neon inline-block ml-1 fill-neon/30" />
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
