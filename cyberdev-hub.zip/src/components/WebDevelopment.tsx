import React from 'react';
import {
  FileCode,
  Braces,
  Component,
  Server,
  Terminal,
  Layout,
  Layers,
  Bot,
  ArrowRight,
  Globe,
  type LucideIcon,
} from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { useRouter } from '../context/RouterContext';
import SmartImage from './SmartImage';

interface WebDevCard {
  title: string;
  icon: LucideIcon;
  description: string;
  route: string;
  badge: string;
  image: string;
}

const cards: WebDevCard[] = [
  {
    title: 'HTML5 & Modern CSS3',
    icon: FileCode,
    description: 'The architectural backbone of the web. Semantic markup, modern CSS Grid, Flexbox, and Tailwind CSS.',
    route: '/web-development/html-css',
    badge: 'Semantic & CSS',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'JavaScript Development',
    icon: Braces,
    description: 'The universal language of the web. Async event loops, modern ES2024+ syntax, DOM reactivity, and APIs.',
    route: '/web-development/javascript',
    badge: 'ES2024 / Async',
    image: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'React Development',
    icon: Component,
    description: 'Build modern reactive interfaces with component architectures, custom hooks, and virtual DOM algorithms.',
    route: '/web-development/react',
    badge: 'RSC & Hooks',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Next.js Full Stack',
    icon: Server,
    description: 'Production React framework with App Router, SSR, Server Actions, edge middleware, and built-in SEO.',
    route: '/web-development/nextjs',
    badge: 'SSR / Edge',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Node.js Backend',
    icon: Terminal,
    description: 'Server-side runtime for high-throughput asynchronous APIs, WebSockets, microservices, and databases.',
    route: '/web-development/nodejs',
    badge: 'Async I/O',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Web Design & Creative UI',
    icon: Layout,
    description: 'Futuristic glassmorphism design, neon cyberpunk palettes, typography, and fluid micro-interactions.',
    route: '/web-development/web-design',
    badge: 'Cyber Aesthetics',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Full Stack Development',
    icon: Layers,
    description: 'Master frontend, backend, PostgreSQL databases, Docker containers, and end-to-end cloud infrastructure.',
    route: '/web-development/fullstack',
    badge: 'End-to-End',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'AI Tools & Automation',
    icon: Bot,
    description: 'Supercharge development velocity with LLMs, code assistants, autonomous agentic workflows, and RAG.',
    route: '/ai-development',
    badge: 'Generative AI',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=600&q=80',
  },
];

const WebDevelopment: React.FC = () => {
  const containerRef = useScrollAnimation();
  const { navigate } = useRouter();

  return (
    <section id="web-dev" ref={containerRef as any} className="py-24 px-4 max-w-7xl mx-auto">
      <div className="flex flex-col items-center mb-14 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-redAccent-500/10 border border-redAccent-500/30 text-redAccent-400 font-mono text-xs mb-3">
          <Globe className="w-3.5 h-3.5 text-redAccent-400" />
          <span>Full Stack Web Engineering & Cloud Stacks</span>
        </div>
        <h2 className="section-title">Web Development</h2>
        <p className="text-gray-400 max-w-2xl text-sm sm:text-base">
          Build modern, resilient web applications with industry-leading frontend and backend technologies. Click any card to view the dedicated architecture breakdown.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => {
          const IconComponent = card.icon;
          return (
            <div
              key={card.title}
              tabIndex={0}
              role="button"
              aria-label={`Explore ${card.title}`}
              onClick={() => navigate(card.route)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  navigate(card.route);
                }
              }}
              className="glass-card category-card p-0 flex flex-col justify-between scroll-animate group cursor-pointer focus:outline-none focus:ring-2 focus:ring-neon-500 hover:border-neon-500 hover:shadow-[0_0_30px_rgba(0,255,65,0.3),0_0_15px_rgba(255,23,68,0.2)]"
            >
              {/* Card Image Thumbnail with Subtle Overlay */}
              <div className="relative h-36 w-full overflow-hidden rounded-t-[calc(1rem-1px)]">
                <SmartImage
                  src={card.image}
                  fallbackSrc="/hacker.jpg"
                  alt={card.title}
                  containerClassName="w-full h-full"
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-card via-cyber-card/60 to-transparent" />
                <div className="absolute top-3 right-3 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-neon-500 animate-ping" />
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyber-deep/80 text-neon-400 border border-neon-500/40 backdrop-blur-xs">
                    {card.badge}
                  </span>
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6 pt-2 flex-1 flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-neon-500/10 border border-neon-500/30 flex items-center justify-center text-neon-500 -mt-7 relative z-10 shadow-lg group-hover:border-neon-400 group-hover:shadow-[0_0_15px_rgba(0,255,65,0.5)] transition-all">
                    <IconComponent className="w-5 h-5" />
                  </div>

                  <h3 className="text-lg font-bold text-white mt-3 group-hover:text-neon-400 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-gray-400 text-xs sm:text-sm mt-2 leading-relaxed">
                    {card.description}
                  </p>
                </div>

                {/* Glowing Explore Button */}
                <div className="mt-5 pt-3 border-t border-cyber-border flex items-center justify-between">
                  <span className="text-xs font-mono text-gray-500 group-hover:text-neon-400 transition-colors">
                    Architecture & Docs
                  </span>
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-neon-500 group-hover:text-neon-300 transition-all">
                    <span>Explore</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default WebDevelopment;
