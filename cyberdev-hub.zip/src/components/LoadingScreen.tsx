import { useState, useEffect, useRef } from 'react';
import SiteLogo from './SiteLogo';

interface LoadingScreenProps {
  onComplete?: () => void;
}

const LoadingScreen = ({ onComplete }: LoadingScreenProps) => {
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [percentage, setPercentage] = useState<number>(0);
  const [isFading, setIsFading] = useState<boolean>(false);

  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const loadingDuration = 2000; // Duration to reach 100%
    const totalDuration = 2500; // Total duration before disappearance (2.5s)
    const intervalTime = 20; // Update interval in ms
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(Math.floor((elapsed / loadingDuration) * 100), 100);
      setPercentage(progress);

      if (progress >= 100) {
        clearInterval(interval);
      }
    }, intervalTime);

    // Start fade-out animation when percentage reaches 100%
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, loadingDuration);

    // Complete loading and hide screen at 2.5s
    const completeTimer = setTimeout(() => {
      setIsVisible(false);
      onCompleteRef.current?.();
    }, totalDuration);

    return () => {
      clearInterval(interval);
      clearTimeout(fadeTimer);
      clearTimeout(completeTimer);
    };
  }, []);

  if (!isVisible) {
    return null;
  }

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#0a0a0f] transition-opacity duration-500 ease-out select-none ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ zIndex: 9999, backgroundColor: '#0a0a0f' }}
    >
      <div className="flex flex-col items-center text-center px-4">
        {/* Animated CyberDev Hub Logo Emblem */}
        <div className="mb-4 transform hover:scale-105 transition-transform duration-300">
          <SiteLogo size="xl" showText={false} withGlow={true} />
        </div>

        {/* Animated CyberDev Hub Title */}
        <h1 className="loading-logo text-3xl sm:text-4xl md:text-5xl font-mono font-bold text-[#00ff41] tracking-wider mb-2">
          CyberDev Hub
        </h1>

        {/* Subtitle */}
        <p className="text-gray-400 font-mono text-sm sm:text-base tracking-widest uppercase mb-6">
          Initializing Systems...
        </p>

        {/* Animated Loading Bar */}
        <div className="loading-bar mb-4" />

        {/* Percentage Counter */}
        <div className="text-[#00ff41] font-mono text-sm sm:text-base font-semibold tracking-wider">
          {percentage}%
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;
