import React, { useState, useMemo, useEffect } from 'react';
import {
  Bot,
  Globe,
  Smartphone,
  Image as ImageIcon,
  Wrench,
  Zap,
  Search,
  X,
  Code2,
  Terminal,
  Cpu,
  Layout,
  Layers,
  Server,
  Box,
  Flame,
  Palette,
  Wand2,
  Sliders,
  Link as LinkIcon,
  Smile,
  Workflow,
  Network,
  ExternalLink,
} from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface Tool {
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  url: string;
}

interface ToolCategory {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  learnMoreUrl: string;
  tools: Tool[];
}

const CATEGORIES: ToolCategory[] = [
  {
    id: 'ai-coding-assistants',
    title: 'AI Coding Assistants',
    icon: Bot,
    learnMoreUrl: 'https://github.com/features/copilot',
    tools: [
      {
        name: 'GitHub Copilot',
        description: 'AI pair programmer offering real-time code completions and chat assistance.',
        icon: Code2,
        url: 'https://github.com/features/copilot',
      },
      {
        name: 'Cursor AI',
        description: 'Next-generation AI-first code editor designed for pair-programming and refactoring.',
        icon: Terminal,
        url: 'https://www.cursor.com',
      },
      {
        name: 'Tabnine',
        description: 'Privacy-focused AI code assistant that runs locally or securely in the cloud.',
        icon: Cpu,
        url: 'https://www.tabnine.com',
      },
    ],
  },
  {
    id: 'ai-website-builders',
    title: 'AI Website Builders',
    icon: Globe,
    learnMoreUrl: 'https://www.framer.com/ai',
    tools: [
      {
        name: 'Wix AI',
        description: 'Conversational site generator that builds custom, responsive websites in minutes.',
        icon: Layout,
        url: 'https://www.wix.com/ai-website-builder',
      },
      {
        name: 'Framer AI',
        description: 'AI-powered canvas to generate, design, and publish production-ready websites.',
        icon: Layers,
        url: 'https://www.framer.com/ai',
      },
      {
        name: 'Hostinger AI',
        description: 'Automated website builder creating ready-to-launch sites with content and images.',
        icon: Server,
        url: 'https://www.hostinger.com/ai-website-builder',
      },
    ],
  },
  {
    id: 'ai-app-builders',
    title: 'AI App Builders',
    icon: Smartphone,
    learnMoreUrl: 'https://flutterflow.io',
    tools: [
      {
        name: 'FlutterFlow',
        description: 'Visual app builder with AI generation to build native mobile and web apps.',
        icon: Smartphone,
        url: 'https://flutterflow.io',
      },
      {
        name: 'Adalo',
        description: 'No-code mobile app builder with AI-driven workflows and component generation.',
        icon: Box,
        url: 'https://www.adalo.com',
      },
      {
        name: 'BuildFire',
        description: 'Enterprise mobile app creation platform powered by customizable AI plugins.',
        icon: Flame,
        url: 'https://buildfire.com',
      },
    ],
  },
  {
    id: 'ai-image-generators',
    title: 'AI Image Generators',
    icon: ImageIcon,
    learnMoreUrl: 'https://www.midjourney.com',
    tools: [
      {
        name: 'Midjourney',
        description: 'Leading AI image generator creating hyper-realistic and artistic visuals.',
        icon: Palette,
        url: 'https://www.midjourney.com',
      },
      {
        name: 'DALL-E 3',
        description: "OpenAI's advanced AI image system understanding nuanced and detailed prompts.",
        icon: Wand2,
        url: 'https://openai.com/dall-e-3',
      },
      {
        name: 'Stable Diffusion',
        description: 'Open-source generative model for creating and fine-tuning visual media.',
        icon: Sliders,
        url: 'https://stability.ai',
      },
    ],
  },
  {
    id: 'ai-developer-tools',
    title: 'AI Developer Tools',
    icon: Wrench,
    learnMoreUrl: 'https://sdk.vercel.ai',
    tools: [
      {
        name: 'Vercel AI SDK',
        description: 'Open-source library to build AI-powered streaming web applications with React.',
        icon: Code2,
        url: 'https://sdk.vercel.ai',
      },
      {
        name: 'LangChain',
        description: 'Framework for developing applications powered by large language models.',
        icon: LinkIcon,
        url: 'https://www.langchain.com',
      },
      {
        name: 'Hugging Face',
        description: 'The open-source platform and hub for machine learning models and datasets.',
        icon: Smile,
        url: 'https://huggingface.co',
      },
    ],
  },
  {
    id: 'ai-automation-tools',
    title: 'AI Automation Tools',
    icon: Zap,
    learnMoreUrl: 'https://zapier.com/ai',
    tools: [
      {
        name: 'Zapier AI',
        description: 'Connect and automate workflows across 6,000+ apps with natural language.',
        icon: Zap,
        url: 'https://zapier.com/ai',
      },
      {
        name: 'Make',
        description: 'Visual platform to design, build, and automate complex workflows with AI.',
        icon: Workflow,
        url: 'https://www.make.com',
      },
      {
        name: 'n8n',
        description: 'Fair-code workflow automation tool with native AI and self-hosting capabilities.',
        icon: Network,
        url: 'https://n8n.io',
      },
    ],
  },
];

const FILTER_CATEGORIES = [
  'All',
  'AI Coding Assistants',
  'AI Website Builders',
  'AI App Builders',
  'AI Image Generators',
  'AI Developer Tools',
  'AI Automation Tools',
];

const AITools: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const containerRef = useScrollAnimation();

  // Ensure visible elements stay visible when filtering or searching
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const elements = el.querySelectorAll('.scroll-animate');
    elements.forEach((child) => {
      const rect = child.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        child.classList.add('animate-visible');
      }
    });
  }, [searchQuery, activeCategory]);

  const filteredCategories = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return CATEGORIES.filter((category) => {
      if (activeCategory !== 'All' && category.title !== activeCategory) {
        return false;
      }
      return true;
    })
      .map((category) => {
        if (!query) {
          return category;
        }

        const categoryTitleMatches = category.title.toLowerCase().includes(query);
        const matchingTools = category.tools.filter(
          (tool) =>
            tool.name.toLowerCase().includes(query) ||
            tool.description.toLowerCase().includes(query)
        );

        if (matchingTools.length > 0) {
          return {
            ...category,
            tools: matchingTools,
          };
        }

        if (categoryTitleMatches) {
          return category;
        }

        return null;
      })
      .filter((category): category is ToolCategory => category !== null);
  }, [searchQuery, activeCategory]);

  return (
    <section id="ai-tools" ref={containerRef as any} className="py-20 px-4 max-w-7xl mx-auto">
      {/* Section Title & Subtitle */}
      <div className="scroll-animate mb-4">
        <h2 className="section-title">AI Tools</h2>
        <p className="text-gray-400 text-center mb-8 max-w-2xl mx-auto">
          Discover AI-powered tools that supercharge your development workflow
        </p>
      </div>

      {/* Search Input */}
      <div className="max-w-md mx-auto mb-8 scroll-animate">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search AI tools..."
            className="w-full pl-12 pr-10 py-3 rounded-xl glass text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-neon-500/50 border border-gray-300/30 dark:border-neon-500/20 text-sm transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200 transition-colors p-1"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Filter Buttons */}
      <div className="flex flex-wrap justify-center gap-2 mb-8 scroll-animate">
        {FILTER_CATEGORIES.map((category) => {
          const isActive = activeCategory === category;
          return (
            <button
              key={category}
              type="button"
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                isActive
                  ? 'bg-neon-500 text-cyber-bg font-semibold shadow-[0_0_15px_rgba(0,255,65,0.3)] scale-105'
                  : 'glass text-gray-700 dark:text-gray-300 hover:text-neon-600 dark:hover:text-neon-400 hover:border-neon-500/30'
              }`}
            >
              {category}
            </button>
          );
        })}
      </div>

      {/* Tools Grid or Empty State */}
      {filteredCategories.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCategories.map((category, index) => {
            const CategoryIcon = category.icon;
            return (
              <div
                key={category.id}
                className={`glass-card p-6 flex flex-col justify-between scroll-animate stagger-${
                  (index % 6) + 1
                } group hover:border-neon-500/40 transition-all duration-300`}
              >
                <div>
                  {/* Category Header */}
                  <div className="flex items-center gap-3 mb-5">
                    <div className="p-2.5 rounded-xl bg-neon-500/10 border border-neon-500/20 text-neon-500 group-hover:scale-105 transition-transform duration-300">
                      <CategoryIcon className="w-6 h-6 text-neon-500" />
                    </div>
                    <h3 className="font-semibold text-xl text-gray-900 dark:text-white group-hover:text-neon-500 transition-colors">
                      {category.title}
                    </h3>
                  </div>

                  {/* Tools List */}
                  <div className="space-y-3 mb-6">
                    {category.tools.map((tool) => {
                      const ToolIcon = tool.icon;
                      return (
                        <a
                          key={tool.name}
                          href={tool.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block p-3 rounded-lg bg-gray-50/50 dark:bg-cyber-bg/40 border border-gray-200/50 dark:border-white/5 hover:border-neon-500/30 hover:bg-neon-500/[0.04] transition-all duration-200 group/tool"
                        >
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2">
                              <ToolIcon className="w-4 h-4 text-neon-500 flex-shrink-0" />
                              <span className="font-medium text-sm text-gray-800 dark:text-gray-200 group-hover/tool:text-neon-500 transition-colors">
                                {tool.name}
                              </span>
                            </div>
                            <ExternalLink className="w-3.5 h-3.5 text-gray-400 dark:text-gray-500 opacity-0 group-hover/tool:opacity-100 transition-opacity flex-shrink-0" />
                          </div>
                          <p className="text-xs text-gray-600 dark:text-gray-400 pl-6 leading-relaxed">
                            {tool.description}
                          </p>
                        </a>
                      );
                    })}
                  </div>
                </div>

                {/* Card Footer: Learn More Link */}
                <div className="pt-4 border-t border-gray-200/40 dark:border-white/5">
                  <a
                    href={category.learnMoreUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-sm font-semibold text-neon-500 hover:text-neon-400 transition-all duration-200 group/link"
                  >
                    Learn More{' '}
                    <span className="ml-1 transition-transform duration-200 group-hover/link:translate-x-1">
                      →
                    </span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-16 glass-card max-w-md mx-auto scroll-animate">
          <Bot className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-800 dark:text-gray-200 font-medium text-lg mb-2">
            No AI tools found
          </p>
          <p className="text-gray-500 dark:text-gray-400 text-sm mb-6 px-4">
            No tools match &ldquo;{searchQuery}&rdquo; in{' '}
            {activeCategory === 'All' ? 'any category' : activeCategory}.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setActiveCategory('All');
            }}
            className="btn-neon text-sm py-2 px-5"
          >
            Reset Filters
          </button>
        </div>
      )}
    </section>
  );
};

export default AITools;
