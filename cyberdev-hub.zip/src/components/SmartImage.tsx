import React, { useState } from 'react';

interface SmartImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
  containerClassName?: string;
}

export const SmartImage: React.FC<SmartImageProps> = ({
  src,
  fallbackSrc = '/hacker.jpg',
  alt = '',
  className = '',
  containerClassName = '',
  ...props
}) => {
  const [loading, setLoading] = useState(true);
  const [imgSrc, setImgSrc] = useState(src);
  const [hasError, setHasError] = useState(false);

  const handleError = () => {
    if (!hasError && fallbackSrc && imgSrc !== fallbackSrc) {
      setImgSrc(fallbackSrc);
      setHasError(true);
    } else {
      setImgSrc('/hacker.jpg');
    }
    setLoading(false);
  };

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      {loading && (
        <div className="absolute inset-0 bg-cyber-card animate-pulse flex items-center justify-center">
          <div className="w-8 h-8 rounded-full border-2 border-neon-500/30 border-t-neon-500 animate-spin" />
        </div>
      )}
      <img
        src={imgSrc}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoading(false)}
        onError={handleError}
        className={`transition-opacity duration-500 ${loading ? 'opacity-0' : 'opacity-100'} ${className}`}
        {...props}
      />
    </div>
  );
};

export default SmartImage;
