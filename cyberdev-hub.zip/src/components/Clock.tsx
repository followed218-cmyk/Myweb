import { useState, useEffect } from 'react';

interface ClockProps {
  className?: string;
}

const Clock = ({ className = '' }: ClockProps) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  const formatTime = (date: Date): string => {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };

  const formatDate = (date: Date): string => {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    const month = months[date.getMonth()];
    const day = date.getDate();
    const year = date.getFullYear();
    return `${month} ${day}, ${year}`;
  };

  return (
    <div
      className={`font-mono text-neon-500 flex flex-col items-center select-none ${className}`}
      aria-label="Digital Clock"
    >
      <span className="text-xs font-semibold tracking-wider [text-shadow:0_0_8px_rgba(0,255,65,0.4)] drop-shadow-[0_0_8px_rgba(0,255,65,0.4)]">
        {formatTime(currentTime)}
      </span>
      <span className="text-[10px] tracking-wide text-neon-500/80 [text-shadow:0_0_4px_rgba(0,255,65,0.25)] drop-shadow-[0_0_4px_rgba(0,255,65,0.25)]">
        {formatDate(currentTime)}
      </span>
    </div>
  );
};

export default Clock;
