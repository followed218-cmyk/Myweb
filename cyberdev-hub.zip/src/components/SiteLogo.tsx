import React, { useState } from 'react';
import { useRouter } from '../context/RouterContext';

export interface SiteLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  clickable?: boolean;
  className?: string;
  imageClassName?: string;
  textClassName?: string;
  withGlow?: boolean;
  withCursor?: boolean;
  onClick?: () => void;
}

const sizeConfig = {
  sm: {
    container: 'h-7 w-7',
    iconSize: 'text-sm',
    textSize: 'text-base sm:text-lg',
    cursorHeight: 'h-4',
  },
  md: {
    container: 'h-9 w-9 sm:h-10 sm:w-10',
    iconSize: 'text-lg',
    textSize: 'text-lg sm:text-xl md:text-2xl',
    cursorHeight: 'h-5',
  },
  lg: {
    container: 'h-12 w-12 sm:h-14 sm:w-14',
    iconSize: 'text-2xl',
    textSize: 'text-2xl sm:text-3xl',
    cursorHeight: 'h-6',
  },
  xl: {
    container: 'h-16 w-16 sm:h-20 sm:w-20',
    iconSize: 'text-3xl',
    textSize: 'text-3xl sm:text-4xl md:text-5xl',
    cursorHeight: 'h-8',
  },
};

export const SiteLogo: React.FC<SiteLogoProps> = ({
  size = 'md',
  showText = false,
  clickable = false,
  className = '',
  imageClassName = '',
  textClassName = '',
  withGlow = true,
  withCursor = false,
  onClick,
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const { navigate } = useRouter();

  const cfg = sizeConfig[size] || sizeConfig.md;

  const handleClick = (e: React.MouseEvent) => {
    if (onClick) {
      onClick();
    } else if (clickable) {
      e.preventDefault();
      navigate('/');
    }
  };

  const glowEffect = withGlow
    ? 'shadow-[0_0_15px_rgba(0,255,65,0.45),0_0_30px_rgba(0,255,65,0.2)] hover:shadow-[0_0_20px_rgba(0,255,65,0.7),0_0_40px_rgba(255,23,68,0.3)]'
    : '';

  const logoGraphic = (
    <div
      className={`relative rounded-xl overflow-hidden flex items-center justify-center flex-shrink-0 bg-cyber-deep/80 border border-neon-500/40 transition-all duration-300 group-hover:border-neon-400 ${cfg.container} ${glowEffect} ${imageClassName}`}
    >
      {!hasError ? (
        <>
          {!isLoaded && (
            <div className="absolute inset-0 bg-cyber-card animate-pulse flex items-center justify-center">
              <span className="text-neon-500 font-mono text-xs">⚡</span>
            </div>
          )}
          <img
            src="/logo.jpg"
            alt="CyberDev Hub Logo"
            loading="eager"
            onLoad={() => setIsLoaded(true)}
            onError={() => {
              setHasError(true);
              setIsLoaded(true);
            }}
            className={`w-full h-full object-contain p-0.5 transform transition-transform duration-300 group-hover:scale-105 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />
        </>
      ) : (
        /* Fallback icon if logo.jpg is absent or corrupt */
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-cyber-surface to-cyber-deep text-neon-500 font-mono font-bold select-none">
          <span className={cfg.iconSize}>⚡</span>
        </div>
      )}
    </div>
  );

  const textElement = showText ? (
    <span
      className={`font-bold font-mono tracking-wider flex items-center text-neon glow-text transition-all duration-300 group-hover:brightness-125 select-none ${cfg.textSize} ${textClassName}`}
    >
      <span>CyberDev Hub</span>
      {withCursor && <span className={`terminal-cursor ${cfg.cursorHeight}`} aria-hidden="true" />}
    </span>
  ) : null;

  const content = (
    <div
      className={`flex items-center gap-2.5 sm:gap-3 group select-none ${
        clickable ? 'cursor-pointer' : ''
      } ${className}`}
      onClick={clickable ? handleClick : undefined}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
      onKeyDown={
        clickable
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleClick(e as any);
              }
            }
          : undefined
      }
      aria-label="CyberDev Hub Branding"
    >
      {logoGraphic}
      {textElement}
    </div>
  );

  return content;
};

export default SiteLogo;
