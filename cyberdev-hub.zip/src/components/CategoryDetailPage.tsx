import React from 'react';
import {
  ArrowLeft,
  ChevronRight,
  ExternalLink,
  BookOpen,
  CheckCircle2,
  Cpu,
  Layers,
  Sparkles,
  Compass,
} from 'lucide-react';
import { useRouter } from '../context/RouterContext';
import { type CategoryDetail } from '../data/categoriesData';
import SmartImage from './SmartImage';

interface CategoryDetailPageProps {
  category: CategoryDetail;
}

export const CategoryDetailPage: React.FC<CategoryDetailPageProps> = ({ category }) => {
  const { navigate, goBack } = useRouter();

  return (
    <div className="min-h-screen pt-20 pb-24 page-enter">
      {/* Breadcrumb Navigation & Back Button Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Breadcrumbs */}
          <nav aria-label="Breadcrumb" className="flex items-center space-x-2 text-xs sm:text-sm font-mono">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-neon-500 transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>Home</span>
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <button
              type="button"
              onClick={() => navigate(category.parentHref)}
              className="text-gray-400 hover:text-neon-500 transition-colors cursor-pointer"
            >
              {category.parentCategory}
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <span className="text-neon-500 font-semibold truncate max-w-[200px] sm:max-w-none">
              {category.title}
            </span>
          </nav>

          {/* Back Button */}
          <button
            type="button"
            onClick={goBack}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl glass border border-neon-500/30 text-neon-500 hover:text-neon-400 hover:border-neon-500 hover:bg-neon-500/10 text-xs sm:text-sm font-medium transition-all duration-200 group cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            <span>Back</span>
          </button>
        </div>
      </div>

      {/* Hero Section with High-Resolution Stock Image */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
        <div className="relative rounded-2xl overflow-hidden border border-neon-500/30 shadow-[0_0_30px_rgba(0,255,65,0.15)]">
          {/* Hero Stock Photography */}
          <div className="relative h-72 sm:h-96 md:h-[450px] w-full">
            <SmartImage
              src={category.heroImage}
              fallbackSrc={category.fallbackImage}
              alt={category.title}
              containerClassName="w-full h-full"
              className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
            />
            {/* Dark cyberpunk overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-cyber-bg via-cyber-bg/80 to-transparent" />
            <div className="absolute inset-0 bg-black/40" />

            {/* Glowing Scanlines overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(0,255,65,0.15),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(255,23,68,0.12),transparent_40%)]" />
          </div>

          {/* Hero Content Header */}
          <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-10 z-10">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="badge-green">{category.badge}</span>
              <span className="badge-red">CyberDev Verified</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white glow-text">
              <span className="bg-gradient-to-r from-neon-500 via-neon-300 to-neon-500 bg-clip-text text-transparent">
                {category.title}
              </span>
            </h1>

            <p className="text-gray-300 text-sm sm:text-base md:text-lg max-w-3xl mt-3 leading-relaxed">
              {category.subtitle}
            </p>
          </div>
        </div>
      </section>

      {/* Main Content Layout */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Columns: Overview, Key Features & Core Topics */}
        <div className="lg:col-span-2 space-y-10">
          {/* Overview Glass Card */}
          <div className="glass-card p-6 sm:p-8 border-l-4 border-l-neon-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-neon-500/10 border border-neon-500/30 flex items-center justify-center text-neon-500">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-white">Technology Overview</h2>
                <span className="text-xs text-neon-400 font-mono">{category.tagline}</span>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed text-sm sm:text-base mt-4">
              {category.overview}
            </p>
          </div>

          {/* Key Features Grid */}
          <div className="glass-card p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-redAccent-500/10 border border-redAccent-500/30 flex items-center justify-center text-redAccent-500">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-white">Key Architectural Features</h2>
                <span className="text-xs text-redAccent-400 font-mono">Core Strengths & Capabilities</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {category.keyFeatures.map((feature, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-cyber-surface/60 border border-cyber-border hover:border-neon-500/40 transition-colors duration-200"
                >
                  <CheckCircle2 className="w-5 h-5 text-neon-500 flex-shrink-0 mt-0.5" />
                  <span className="text-xs sm:text-sm text-gray-300 leading-relaxed">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Real Learning Content: Core Topics */}
          <div className="glass-card p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-neon-500/10 border border-neon-500/30 flex items-center justify-center text-neon-500">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-white">Curriculum & Deep Topics</h2>
                <span className="text-xs text-neon-400 font-mono">Engineered Learning Progression</span>
              </div>
            </div>

            <div className="space-y-4">
              {category.coreTopics.map((topic, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-cyber-surface/70 border border-cyber-border hover:border-neon-500/30 transition-all duration-200"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-neon-500/20 text-neon-500 text-xs font-mono font-bold flex items-center justify-center border border-neon-500/30">
                      {idx + 1}
                    </span>
                    <h3 className="text-sm sm:text-base font-semibold text-white">{topic.title}</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-gray-400 mt-2 ml-8 leading-relaxed">
                    {topic.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Learning Resources */}
          <div className="glass-card p-6 sm:p-8">
            <h2 className="text-xl sm:text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="text-neon-500">⚡</span> Hands-On Learning Resources
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {category.learningResources.map((res, idx) => (
                <a
                  key={idx}
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 rounded-xl bg-cyber-surface/80 border border-cyber-border hover:border-neon-500 hover:shadow-[0_0_15px_rgba(0,255,65,0.2)] transition-all duration-200 group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neon-500/10 text-neon-400 border border-neon-500/20">
                        {res.type}
                      </span>
                      <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-neon-500 transition-colors" />
                    </div>
                    <h4 className="font-semibold text-sm text-white group-hover:text-neon-400 transition-colors">
                      {res.title}
                    </h4>
                    <p className="text-xs text-gray-400 mt-1.5 leading-relaxed">{res.desc}</p>
                  </div>
                  <span className="mt-4 text-xs font-medium text-neon-500 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Start Learning →
                  </span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Column: Tech Stack, Official Docs & Related Categories */}
        <div className="space-y-8">
          {/* Tech Stack & Tooling */}
          <div className="glass-card p-6 border-t-2 border-t-neon-500">
            <div className="flex items-center gap-2 mb-4">
              <Cpu className="w-5 h-5 text-neon-500" />
              <h3 className="text-lg font-bold text-white">Technologies & Tools</h3>
            </div>
            <div className="space-y-3">
              {category.techStack.map((tech, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-cyber-surface/60 border border-cyber-border/60"
                >
                  <span className="text-sm font-semibold text-white">{tech.name}</span>
                  <span className="text-xs font-mono text-neon-400 px-2 py-0.5 rounded bg-neon-500/10 border border-neon-500/20">
                    {tech.role}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Official Documentation Links */}
          <div className="glass-card p-6 border-t-2 border-t-redAccent-500">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-redAccent-500" />
              <h3 className="text-lg font-bold text-white">Official Documentation</h3>
            </div>
            <div className="space-y-3">
              {category.documentationLinks.map((doc, idx) => (
                <a
                  key={idx}
                  href={doc.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-3 rounded-lg bg-cyber-surface/60 border border-cyber-border hover:border-redAccent-500/50 hover:bg-cyber-surface transition-all duration-200 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-white group-hover:text-redAccent-400 transition-colors">
                      {doc.title}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-gray-500 group-hover:text-redAccent-400 transition-colors" />
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{doc.desc}</p>
                </a>
              ))}
            </div>
          </div>

          {/* Related Development Categories */}
          <div className="glass-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Layers className="w-5 h-5 text-neon-500" />
              <h3 className="text-lg font-bold text-white">Related Categories</h3>
            </div>
            <div className="space-y-3">
              {category.relatedRoutes.map((rel, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => navigate(rel.route)}
                  className="w-full text-left p-3 rounded-lg bg-cyber-surface/60 border border-cyber-border hover:border-neon-500 hover:shadow-[0_0_12px_rgba(0,255,65,0.2)] transition-all duration-200 group cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-white group-hover:text-neon-400 transition-colors">
                      {rel.title}
                    </span>
                    <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-neon-400 group-hover:translate-x-1 transition-all" />
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{rel.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Explore More Call To Action */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-cyber-card via-cyber-surface to-[#0d1612] border border-neon-500/40 shadow-[0_0_20px_rgba(0,255,65,0.2)] text-center">
            <h4 className="font-mono font-bold text-lg text-white mb-2">Explore All CyberDev Tech</h4>
            <p className="text-xs text-gray-400 mb-6 leading-relaxed">
              Explore our complete catalogue of mobile engineering, full-stack web platforms, and cybersecurity tools.
            </p>
            <button
              type="button"
              onClick={() => navigate('/')}
              className="w-full btn-neon-solid cursor-pointer text-sm font-bold uppercase tracking-wider"
            >
              Explore All Categories
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryDetailPage;
