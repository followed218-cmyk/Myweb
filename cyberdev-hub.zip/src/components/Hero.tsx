import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

const TERMINAL_LINES = [
  '> Initializing Developer Environment...',
  '> Loading Development Tools...',
  '> System Ready.',
];

const Hero = () => {
  const [lines, setLines] = useState<string[]>([]);
  const [currentText, setCurrentText] = useState('');
  const [lineIndex, setLineIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);

  useEffect(() => {
    if (lineIndex >= TERMINAL_LINES.length) return;

    const targetLine = TERMINAL_LINES[lineIndex];

    if (charIndex < targetLine.length) {
      const timeout = setTimeout(() => {
        setCurrentText(targetLine.slice(0, charIndex + 1));
        setCharIndex((prev) => prev + 1);
      }, 40);
      return () => clearTimeout(timeout);
    } else if (lineIndex < TERMINAL_LINES.length - 1) {
      const timeout = setTimeout(() => {
        setLines((prev) => [...prev, targetLine]);
        setCurrentText('');
        setCharIndex(0);
        setLineIndex((prev) => prev + 1);
      }, 400);
      return () => clearTimeout(timeout);
    }
  }, [lineIndex, charIndex]);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center hero-bg overflow-hidden"
    >
      {/* Dark overlay */}
      <div className="bg-black/70 absolute inset-0" aria-hidden="true" />

      {/* Main Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center flex flex-col items-center justify-center">
        {/* Main Heading */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight glow-text">
          <span className="bg-gradient-to-r from-neon-500 via-neon-300 to-neon-500 bg-clip-text text-transparent inline-block">
            BUILD. CODE. INNOVATE.
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mt-6">
          Explore the world of Android development, web technologies, AI-powered tools and next-generation digital innovation.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
          <a href="#app-dev" className="btn-neon-solid">
            Explore Projects
          </a>
          <a href="#resources" className="btn-neon">
            Developer Resources
          </a>
        </div>

        {/* Terminal Animation */}
        <div className="bg-black/80 border border-neon/20 rounded-lg p-4 font-mono text-sm text-neon-500 w-full max-w-lg mx-auto mt-12 text-left shadow-2xl backdrop-blur-sm">
          {/* Terminal Header */}
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-neon/10">
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500 inline-block" />
              <span className="w-3 h-3 rounded-full bg-yellow-500 inline-block" />
              <span className="w-3 h-3 rounded-full bg-green-500 inline-block" />
            </div>
            <span className="text-xs text-gray-400 font-mono ml-2 select-none">terminal</span>
          </div>

          {/* Terminal Body */}
          <div className="space-y-1.5 min-h-[4.5rem]">
            {lines.map((line, idx) => (
              <div key={idx} className="leading-relaxed">
                {line}
              </div>
            ))}
            <div className="leading-relaxed flex items-center">
              <span>{currentText}</span>
              <span className="terminal-cursor" aria-hidden="true" />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <a
        href="#app-dev"
        aria-label="Scroll down to projects"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-neon-500 hover:text-neon-400 transition-colors duration-300 animate-bounce"
      >
        <ChevronDown className="w-8 h-8" />
      </a>
    </section>
  );
};

export default Hero;
