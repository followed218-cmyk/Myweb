import React from 'react';
import {
  FolderGit2,
  GitBranch,
  BookOpen,
  GraduationCap,
  Wrench,
  Globe,
  Layout,
  ExternalLink,
  type LucideIcon,
} from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface ResourceCard {
  title: string;
  icon: LucideIcon;
  description: string;
  link: string;
}

const resources: ResourceCard[] = [
  {
    title: 'GitHub Repositories',
    icon: FolderGit2,
    description: 'Curated open-source repositories, developer boilerplate templates, and production architectures.',
    link: 'https://github.com/explore',
  },
  {
    title: 'Open Source Projects',
    icon: GitBranch,
    description: 'Contribute to cutting-edge community projects and collaborate with developers globally.',
    link: 'https://opensource.guide',
  },
  {
    title: 'Android Documentation',
    icon: BookOpen,
    description: 'Official guides, Jetpack Compose references, and Android architecture components.',
    link: 'https://developer.android.com/docs',
  },
  {
    title: 'Programming Tutorials',
    icon: GraduationCap,
    description: 'In-depth interactive tutorials covering modern systems programming, web stacks, and algorithms.',
    link: 'https://www.freecodecamp.org',
  },
  {
    title: 'APK Tools',
    icon: Wrench,
    description: 'Essential toolkits for Android APK disassembly, decompiling, manifest inspection, and security testing.',
    link: 'https://apktool.org',
  },
  {
    title: 'Developer APIs',
    icon: Globe,
    description: 'Extensive directory of free and public APIs for machine learning, data feeds, and web integrations.',
    link: 'https://publicapis.io',
  },
  {
    title: 'UI Components',
    icon: Layout,
    description: 'Futuristic glassmorphism design kits, accessible component libraries, and Tailwind CSS templates.',
    link: 'https://ui.shadcn.com',
  },
  {
    title: 'Useful Websites',
    icon: ExternalLink,
    description: 'Handpicked bookmarks for cheat sheets, regex debuggers, web validators, and dev playgrounds.',
    link: 'https://devdocs.io',
  },
];

const Resources: React.FC = () => {
  const containerRef = useScrollAnimation();

  return (
    <section id="resources" ref={containerRef as any} className="py-20 px-4 max-w-7xl mx-auto">
      <h2 className="section-title">Developer Resources</h2>
      <p className="text-gray-400 text-center mb-12">
        Essential tools, official documentation, and learning resources to power your engineering journey
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {resources.map((item) => {
          const IconComponent = item.icon;
          return (
            <div
              key={item.title}
              className="glass-card p-6 scroll-animate flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-neon-500/10 border border-neon-500/20 flex items-center justify-center text-neon-500 mb-4">
                  <IconComponent className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-white mt-2">{item.title}</h3>
                <p className="text-gray-400 text-sm mt-2 leading-relaxed">{item.description}</p>
              </div>
              <a
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 text-neon-500 hover:text-neon-400 font-medium text-sm inline-flex items-center gap-1 group transition-colors"
              >
                <span>Visit Resource</span>
                <ExternalLink className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default Resources;
