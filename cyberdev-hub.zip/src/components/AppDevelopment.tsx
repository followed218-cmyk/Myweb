import React from 'react';
import {
  Smartphone,
  Code,
  Code2,
  Unlock,
  FileSearch,
  Palette,
  Laptop,
  Layers,
  ArrowRight,
  Sparkles,
  type LucideIcon,
} from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { useRouter } from '../context/RouterContext';
import SmartImage from './SmartImage';

interface AppDevCard {
  title: string;
  icon: LucideIcon;
  description: string;
  route: string;
  badge: string;
  image: string;
}

const cards: AppDevCard[] = [
  {
    title: 'Android App Development',
    icon: Smartphone,
    description: 'Build powerful Android applications with modern architecture patterns, Jetpack Compose, and best practices.',
    route: '/app-development/android',
    badge: 'Compose & Jetpack',
    image: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Kotlin Development',
    icon: Code,
    description: 'Write concise, safe, and expressive code with Kotlin for Android, multiplatform, and backend systems.',
    route: '/app-development/kotlin',
    badge: 'Multiplatform',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Java Development',
    icon: Code2,
    description: 'Master the foundational JVM language for high-performance enterprise systems and Android core architectures.',
    route: '/app-development/java',
    badge: 'JVM Enterprise',
    image: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'APK Reverse Engineering',
    icon: Unlock,
    description: 'Analyze, disassemble, and understand APK bytecode internals for ethical security research and auditing.',
    route: '/app-development/apk-reverse-engineering',
    badge: 'Security / Dex',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'APK Analysis & Security',
    icon: FileSearch,
    description: 'Deep dive into APK structure, AndroidManifest permissions, and component hardening against threats.',
    route: '/app-development/apk-analysis',
    badge: 'Static Auditing',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'App UI/UX Design',
    icon: Palette,
    description: 'Design intuitive, cyber-inspired mobile interfaces and Material You component systems.',
    route: '/app-development/app-ui-ux-design',
    badge: 'Material You',
    image: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Android Studio',
    icon: Laptop,
    description: 'Master Google’s official IDE for Android with memory profilers, Gradle optimization, and debugging tools.',
    route: '/app-development/android-studio',
    badge: 'IDE & Profiling',
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=600&q=80',
  },
  {
    title: 'Flutter Development',
    icon: Layers,
    description: 'Build beautiful, buttery smooth cross-platform applications for Android, iOS, and Web with Dart.',
    route: '/app-development/flutter',
    badge: 'Impeller Engine',
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=600&q=80',
  },
];

const AppDevelopment: React.FC = () => {
  const containerRef = useScrollAnimation();
  const { navigate } = useRouter();

  return (
    <section id="app-dev" ref={containerRef as any} className="py-24 px-4 max-w-7xl mx-auto">
      <div className="flex flex-col items-center mb-14 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-500/10 border border-neon-500/30 text-neon-400 font-mono text-xs mb-3">
          <Sparkles className="w-3.5 h-3.5 text-neon-400" />
          <span>Mobile Ecosystem & Binary Auditing</span>
        </div>
        <h2 className="section-title">App Development</h2>
        <p className="text-gray-400 max-w-2xl text-sm sm:text-base">
          Master native Android engineering, cross-platform apps, and deep-dive APK security research. Click any card to explore its dedicated curriculum.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => {
          const IconComponent = card.icon;
          return (
            <div
              key={card.title}
              tabIndex={0}
              role="button"
              aria-label={`Explore ${card.title}`}
              onClick={() => navigate(card.route)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  navigate(card.route);
                }
              }}
              className="glass-card category-card p-0 flex flex-col justify-between scroll-animate group cursor-pointer focus:outline-none focus:ring-2 focus:ring-neon-500 hover:border-neon-500 hover:shadow-[0_0_30px_rgba(0,255,65,0.3),0_0_15px_rgba(255,23,68,0.2)]"
            >
              {/* Card Image Thumbnail with Subtle Overlay */}
              <div className="relative h-36 w-full overflow-hidden rounded-t-[calc(1rem-1px)]">
                <SmartImage
                  src={card.image}
                  fallbackSrc="/hacker.jpg"
                  alt={card.title}
                  containerClassName="w-full h-full"
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-card via-cyber-card/60 to-transparent" />
                <div className="absolute top-3 right-3 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-redAccent-500 animate-ping" />
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyber-deep/80 text-neon-400 border border-neon-500/40 backdrop-blur-xs">
                    {card.badge}
                  </span>
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6 pt-2 flex-1 flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-neon-500/10 border border-neon-500/30 flex items-center justify-center text-neon-500 -mt-7 relative z-10 shadow-lg group-hover:border-neon-400 group-hover:shadow-[0_0_15px_rgba(0,255,65,0.5)] transition-all">
                    <IconComponent className="w-5 h-5" />
                  </div>

                  <h3 className="text-lg font-bold text-white mt-3 group-hover:text-neon-400 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-gray-400 text-xs sm:text-sm mt-2 leading-relaxed">
                    {card.description}
                  </p>
                </div>

                {/* Glowing Explore Button */}
                <div className="mt-5 pt-3 border-t border-cyber-border flex items-center justify-between">
                  <span className="text-xs font-mono text-gray-500 group-hover:text-neon-400 transition-colors">
                    Dedicated Guide
                  </span>
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-neon-500 group-hover:text-neon-300 transition-all">
                    <span>Explore</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default AppDevelopment;
