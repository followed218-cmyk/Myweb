import React, { useState, useEffect } from 'react';
import { Sun, Moon, Search, Menu, X, Github } from 'lucide-react';
import { FaTelegram } from 'react-icons/fa6';
import { navLinks, socialLinks } from '../config/socialLinks';
import { useRouter } from '../context/RouterContext';
import Clock from './Clock';
import SiteLogo from './SiteLogo';

interface NavbarProps {
  theme: string;
  toggleTheme: () => void;
  onSearchOpen: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ theme, toggleTheme, onSearchOpen }) => {
  const [isScrolled, setIsScrolled] = useState<boolean>(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const { navigate } = useRouter();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    href: string
  ) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    navigate(href);
  };

  const githubUrl =
    socialLinks.find((s) => s.name.toLowerCase() === 'github')?.url ||
    'https://github.com';
  const telegramUrl =
    socialLinks.find((s) => s.name.toLowerCase() === 'telegram')?.url ||
    'https://telegram.org';

  return (
    <header
      className={`fixed top-0 left-0 right-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'glass border-b border-neon/20 shadow-lg shadow-black/40 py-3'
          : 'bg-transparent border-b border-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-12">
          {/* Left: Custom Image Branding Logo + Text */}
          <div className="flex-shrink-0">
            <SiteLogo
              size="md"
              showText={true}
              clickable={true}
              withGlow={true}
              withCursor={true}
              onClick={() => {
                setIsMobileMenuOpen(false);
                navigate('/');
              }}
            />
          </div>

          {/* Center (Desktop): Nav Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-3 xl:space-x-5">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="relative px-2.5 py-1.5 text-xs lg:text-sm font-medium tracking-wide text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon transition-colors duration-200 group"
              >
                <span>{link.name}</span>
                {/* Subtle glow underline effect */}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-neon shadow-[0_0_8px_#00ff41,0_0_12px_rgba(0,255,65,0.6)] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right: Clock, Search, Theme Toggle, Social Shortcuts & Mobile Toggle */}
          <div className="flex items-center space-x-2">
            {/* Live Digital Clock (hidden on mobile, visible on desktop) */}
            <div className="hidden lg:flex items-center px-3 py-1 rounded-lg glass border border-neon-500/20 mr-1">
              <Clock />
            </div>

            {/* Search Button */}
            <button
              type="button"
              onClick={onSearchOpen}
              className="p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-neon"
              title="Search (Ctrl+K)"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Theme Toggle */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-neon"
              title={
                theme === 'dark'
                  ? 'Switch to light mode'
                  : 'Switch to dark mode'
              }
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-neon" />
              ) : (
                <Moon className="w-5 h-5 text-neon" />
              )}
            </button>

            {/* Desktop Social Shortcuts */}
            <div className="hidden md:flex items-center space-x-2">
              <div className="h-5 w-px bg-gray-300 dark:bg-gray-700 mx-1" />
              <a
                href={githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-neon"
                title="GitHub"
                aria-label="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href={telegramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-neon"
                title="Telegram"
                aria-label="Telegram"
              >
                <FaTelegram className="w-5 h-5" />
              </a>
            </div>

            {/* Mobile Hamburger Menu Button */}
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen((prev) => !prev)}
              className="md:hidden p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-neon"
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-neon" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Full-Width Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden mobile-nav-enter glass border-b border-neon/20 px-4 pt-3 pb-5 mt-2 space-y-4 shadow-2xl">
          {/* Mobile Branding Header */}
          <div className="flex items-center justify-between pb-3 border-b border-neon/15">
            <SiteLogo
              size="sm"
              showText={true}
              clickable={true}
              onClick={() => {
                setIsMobileMenuOpen(false);
                navigate('/');
              }}
            />
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neon-500/10 text-neon-400 border border-neon-500/25">
              Portal
            </span>
          </div>

          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-3 py-2.5 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 flex items-center justify-between group"
              >
                <span>{link.name}</span>
                <span className="text-neon opacity-0 group-hover:opacity-100 transition-opacity duration-200 font-mono">
                  ›
                </span>
              </a>
            ))}
          </nav>

          {/* Mobile Social Shortcuts */}
          <div className="pt-3 border-t border-neon/15 flex items-center justify-around">
            <a
              href={githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 border border-transparent hover:border-neon/30"
              aria-label="GitHub"
            >
              <Github className="w-5 h-5" />
              <span>GitHub</span>
            </a>
            <a
              href={telegramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-neon dark:hover:text-neon hover:bg-neon/10 transition-all duration-200 border border-transparent hover:border-neon/30"
              aria-label="Telegram"
            >
              <FaTelegram className="w-5 h-5" />
              <span>Telegram</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
